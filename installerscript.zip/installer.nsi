; ========================================================
; uDiscMounter Installer
; ========================================================

!include "LogicLib.nsh"
!include "WinVer.nsh"

!define APPNAME "uDiscMounterCLI"
!define VERSION "26.0"
!define VERSION_FULL "26.0.0.0"

Name "${APPNAME} ${VERSION}"
OutFile "uDiscMounterCLI_Setup.exe"
InstallDir "$PROGRAMFILES\${APPNAME}"
RequestExecutionLevel admin

; ========================================================
; EXE FILE VERSION INFO (tampil di Properties > Details)
; ========================================================

VIProductVersion "${VERSION_FULL}"
VIFileVersion    "${VERSION_FULL}"

VIAddVersionKey "ProductName"      "uDiscMounterCLI"
VIAddVersionKey "ProductVersion"   "${VERSION}"
VIAddVersionKey "FileVersion"      "${VERSION_FULL}"
VIAddVersionKey "FileDescription"  "uDiscMounterCLI Installer"
VIAddVersionKey "CompanyName"      "ARImetic"
VIAddVersionKey "LegalCopyright"   "Copyright (c) 2015 - 2026 ARImetic. All Rights Reserved."
VIAddVersionKey "LegalTrademarks"  "uDiscMounter is a trademark of ARImetic."
VIAddVersionKey "OriginalFilename" "uDiscMounterCLI_Setup.exe"
VIAddVersionKey "InternalName"     "uDiscMounterCLI_Setup"
VIAddVersionKey "Comments"         "Virtual disc image mounter for Windows"

Var ProgramFolder
; ========================================================
; UI DESIGN — Classic (no MUI, no BMP)
; ========================================================

Caption "${APPNAME} Installer"
BrandingText "ARImetic Software."

InstProgressFlags smooth colored

; ========================================================
; PAGES — Classic
; ========================================================

Page license
Page directory
Page instfiles
UninstPage uninstConfirm
UninstPage instfiles

LicenseData "2.0\eula.txt"

; ========================================================
; HELPER MACROS — PATH management
; ========================================================

!macro AddToSystemPath
    ReadRegStr $0 HKLM "SYSTEM\CurrentControlSet\Control\Session Manager\Environment" "Path"

    Push $0
    Push "$INSTDIR"
    Call StrContainsNoCase
    Pop $1

    ${If} $1 == "0"
        StrCpy $0 "$0;$INSTDIR"
        WriteRegExpandStr HKLM "SYSTEM\CurrentControlSet\Control\Session Manager\Environment" "Path" "$0"
        SendMessage 0xFFFF 0x001A 0 "STR:Environment" /TIMEOUT=500
    ${EndIf}
!macroend

!macro RemoveFromSystemPath
    ReadRegStr $0 HKLM "SYSTEM\CurrentControlSet\Control\Session Manager\Environment" "Path"

    Push $0
    Push ";$INSTDIR"
    Push ""
    Call un.StrReplace
    Pop $0

    Push $0
    Push "$INSTDIR;"
    Push ""
    Call un.StrReplace
    Pop $0

    Push $0
    Push "$INSTDIR"
    Push ""
    Call un.StrReplace
    Pop $0

    WriteRegExpandStr HKLM "SYSTEM\CurrentControlSet\Control\Session Manager\Environment" "Path" "$0"
    SendMessage 0xFFFF 0x001A 0 "STR:Environment" /TIMEOUT=500
!macroend

; ========================================================
; INSTALL SECTION
; ========================================================

Section "Install" SecInstall

    SetDetailsPrint none

    ; --- Detect OS ---
    StrCpy $ProgramFolder ""

    ${If} ${AtLeastWin10}
        StrCpy $ProgramFolder "4.0"
    ${ElseIf} ${AtLeastWinVista}
        StrCpy $ProgramFolder "2.0"
    ${Else}
        MessageBox MB_ICONSTOP "Windows version not supported!$\nMinimum requirement: Windows Vista."
        Quit
    ${EndIf}

    ; --- Install main executable ---
    SetOutPath "$INSTDIR"

    ${If} $ProgramFolder == "2.0"
        File "2.0\uDiscMounterCLI.exe"
    ${Else}
        File "4.0\uDiscMounterCLI.exe"
    ${EndIf}

    ; --- Install driver files ---
    SetOutPath "$WINDIR"
    File "Driver\IsoCmd.exe"
    File "Driver\ISODrive.sys"
    File "Driver\ISODrv64.sys"

    ; --- Silent driver install ---
    ExecWait '"$WINDIR\IsoCmd.exe" -install' $0

    ; --- Desktop shortcut ---
    CreateShortcut "$DESKTOP\uDiscMounterCLI.lnk" "$INSTDIR\uDiscMounterCLI.exe"

    ; --- Start Menu shortcuts ---
    CreateDirectory "$SMPROGRAMS\${APPNAME}"
    CreateShortcut "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk"  "$INSTDIR\uDiscMounterCLI.exe"
    CreateShortcut "$SMPROGRAMS\${APPNAME}\Uninstall.lnk"   "$INSTDIR\Uninstall.exe"

    ; --- Add to system PATH ---
    !insertmacro AddToSystemPath

    ; --- File associations ---
    WriteRegStr HKCR "uDiscMounterFile"                         "" "Disc Image File"
    WriteRegStr HKCR "uDiscMounterFile\DefaultIcon"             "" "$INSTDIR\uDiscMounterCLI.exe,0"
    WriteRegStr HKCR "uDiscMounterFile\shell"                   "" "open"
    WriteRegStr HKCR "uDiscMounterFile\shell\open"              "" "Mount with uDiscMounter"
    WriteRegStr HKCR "uDiscMounterFile\shell\open\command"      "" '"$INSTDIR\uDiscMounterCLI.exe" "%1"'

    WriteRegStr HKCR ".iso"     "" "uDiscMounterFile"
    WriteRegStr HKCR ".img"     "" "uDiscMounterFile"
    WriteRegStr HKCR ".bin"     "" "uDiscMounterFile"
    WriteRegStr HKCR ".cue"     "" "uDiscMounterFile"
    WriteRegStr HKCR ".mdf"     "" "uDiscMounterFile"
    WriteRegStr HKCR ".mds"     "" "uDiscMounterFile"
    WriteRegStr HKCR ".nrg"     "" "uDiscMounterFile"
    WriteRegStr HKCR ".uif"     "" "uDiscMounterFile"
    WriteRegStr HKCR ".daa"     "" "uDiscMounterFile"

    ; --- Add/Remove Programs entry ---
    WriteRegStr   HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" "DisplayName"     "${APPNAME}"
    WriteRegStr   HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" "UninstallString" "$\"$INSTDIR\Uninstall.exe$\""
    WriteRegStr   HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" "DisplayIcon"     "$INSTDIR\uDiscMounterCLI.exe"
    WriteRegStr   HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" "DisplayVersion"  "${VERSION}"
    WriteRegStr   HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" "Publisher"       "ARImetic"
    WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" "NoModify"        1
    WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" "NoRepair"        1

    ; --- Write uninstaller ---
    WriteUninstaller "$INSTDIR\Uninstall.exe"

    ; --- Refresh shell icons ---
    System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, i 0, i 0)'

SectionEnd

; ========================================================
; UNINSTALL SECTION
; ========================================================

Section "Uninstall"

    SetDetailsPrint none

    ; --- Remove driver ---
    ExecWait '"$WINDIR\IsoCmd.exe" -remove' $0

    ; --- Delete driver files ---
    Delete "$WINDIR\IsoCmd.exe"
    Delete "$WINDIR\ISODrive.sys"
    Delete "$WINDIR\ISODrv64.sys"

    ; --- Remove from system PATH ---
    !insertmacro RemoveFromSystemPath

    ; --- Delete shortcuts ---
    Delete "$DESKTOP\uDiscMounterCLI.lnk"
    Delete "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk"
    Delete "$SMPROGRAMS\${APPNAME}\Uninstall.lnk"
    RMDir  "$SMPROGRAMS\${APPNAME}"

    ; --- Remove file associations (only if still ours) ---
    DeleteRegKey HKCR "uDiscMounterFile"

    ReadRegStr $0 HKCR ".iso" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".iso"
    ${EndIf}

    ReadRegStr $0 HKCR ".img" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".img"
    ${EndIf}

    ReadRegStr $0 HKCR ".bin" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".bin"
    ${EndIf}

    ReadRegStr $0 HKCR ".cue" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".cue"
    ${EndIf}

    ReadRegStr $0 HKCR ".mdf" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".mdf"
    ${EndIf}

    ReadRegStr $0 HKCR ".mds" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".mds"
    ${EndIf}

    ReadRegStr $0 HKCR ".nrg" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".nrg"
    ${EndIf}

    ReadRegStr $0 HKCR ".uif" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".uif"
    ${EndIf}

    ReadRegStr $0 HKCR ".daa" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".daa"
    ${EndIf}

    ; --- Remove Add/Remove Programs entry ---
    DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}"

    ; --- Delete program files ---
    Delete "$INSTDIR\uDiscMounterCLI.exe"
    Delete "$INSTDIR\Uninstall.exe"
    RMDir  "$INSTDIR"

    ; --- Refresh shell icons ---
    System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, i 0, i 0)'

SectionEnd

; ========================================================
; FUNCTIONS
; ========================================================

Function .onInit
    UserInfo::GetAccountType
    Pop $0
    ${If} $0 != "admin"
        MessageBox MB_ICONSTOP "Administrator rights are required to install ${APPNAME}."
        Abort
    ${EndIf}
FunctionEnd

Function un.onInit
    MessageBox MB_YESNO|MB_ICONQUESTION "Are you sure you want to uninstall ${APPNAME}?" IDYES +2
    Abort
FunctionEnd

; ========================================================
; HELPER FUNCTION: StrContainsNoCase
; ========================================================
Function StrContainsNoCase
    Exch $R0
    Exch
    Exch $R1
    Push $R2
    Push $R3

    StrCpy $R2 $R1
    StrCpy $R3 $R0

    Push $R2
    Push $R3
    Call StrStr
    Pop $R2

    ${If} $R2 != ""
        StrCpy $R0 "1"
    ${Else}
        StrCpy $R0 "0"
    ${EndIf}

    Pop $R3
    Pop $R2
    Exch $R1
    Exch
    Exch $R0
FunctionEnd

; ========================================================
; HELPER FUNCTION: StrStr
; ========================================================
Function StrStr
    Exch $R1
    Exch
    Exch $R0
    Push $R2
    Push $R3
    Push $R4
    Push $R5

    StrLen $R3 $R1
    StrCpy $R4 0

    loop:
        StrCpy $R2 $R0 $R3 $R4
        ${If} $R2 == $R1
            StrCpy $R0 $R0 "" $R4
            GoTo done
        ${EndIf}
        IntOp $R4 $R4 + 1
        StrCpy $R5 $R0 1 $R4
        ${If} $R5 == ""
            StrCpy $R0 ""
            GoTo done
        ${EndIf}
        GoTo loop
    done:

    Pop $R5
    Pop $R4
    Pop $R3
    Pop $R2
    Exch $R1
    Exch
    Exch $R0
FunctionEnd

; ========================================================
; UNINSTALL HELPER FUNCTION: un.StrReplace
; ========================================================
Function un.StrReplace
    Exch $R2
    Exch
    Exch $R1
    Exch
    Exch $R0
    Push $R3
    Push $R4
    Push $R5
    Push $R6

    StrLen $R4 $R1
    StrCpy $R3 ""
    StrCpy $R5 $R0

    loop:
        StrLen $R6 $R5
        ${If} $R6 < $R4
            StrCpy $R3 "$R3$R5"
            GoTo done
        ${EndIf}
        StrCpy $R6 $R5 $R4
        ${If} $R6 == $R1
            StrCpy $R3 "$R3$R2"
            StrCpy $R5 $R5 "" $R4
        ${Else}
            StrCpy $R3 "$R3$R6" "" 0
            StrCpy $R6 $R5 1
            StrCpy $R3 "$R3$R6"
            StrCpy $R5 $R5 "" 1
        ${EndIf}
        GoTo loop
    done:

    StrCpy $R0 $R3
    Pop $R6
    Pop $R5
    Pop $R4
    Pop $R3
    Exch $R2
    Exch
    Exch $R1
    Exch
    Exch $R0
FunctionEnd