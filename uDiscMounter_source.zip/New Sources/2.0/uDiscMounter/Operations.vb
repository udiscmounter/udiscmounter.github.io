Imports System.Diagnostics
Module Operations
    Public Function MountISO(ByVal driveLetter As String, ByVal isoPath As String) As String
        Try
            'Pastikan ada ":" di drive
            If driveLetter.EndsWith(":") = False Then
                driveLetter &= ":"
            End If

            'Bentuk perintah
            Dim args As String = "-mount " & driveLetter & " """ & isoPath & """"

            Dim p As New Process()
            p.StartInfo.FileName = "isocmd.exe"
            p.StartInfo.Arguments = args
            p.StartInfo.UseShellExecute = False
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.RedirectStandardError = True
            p.StartInfo.CreateNoWindow = True

            p.Start()

            Dim output As String = p.StandardOutput.ReadToEnd()
            Dim err As String = p.StandardError.ReadToEnd()

            p.WaitForExit()

            If err.Trim() <> "" Then
                Return "ERROR: " & err
            Else
                Return output
            End If

        Catch ex As Exception
            Return "Exception: " & ex.Message
        End Try
    End Function

    Public Function EjectISO(ByVal driveLetter As String) As String
        Try
            'Pastikan ada ":" di drive
            If driveLetter.EndsWith(":") = False Then
                driveLetter &= ":"
            End If

            'Perintah isocmd
            Dim args As String = "-eject " & driveLetter

            Dim p As New Process()
            p.StartInfo.FileName = "isocmd.exe"
            p.StartInfo.Arguments = args
            p.StartInfo.UseShellExecute = False
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.RedirectStandardError = True
            p.StartInfo.CreateNoWindow = True

            p.Start()

            Dim output As String = p.StandardOutput.ReadToEnd()
            Dim err As String = p.StandardError.ReadToEnd()

            p.WaitForExit()

            If err.Trim() <> "" Then
                Return "ERROR: " & err
            Else
                Return output
            End If

        Catch ex As Exception
            Return "Exception: " & ex.Message
        End Try
    End Function

    ''' <summary>
    ''' Mengembalikan daftar drive letter yang saat ini sedang dipakai (ada ISO ter-mount).
    ''' Menggunakan "isocmd.exe -print" lalu cek apakah drive punya label mount.
    ''' </summary>
    Public Function GetUsedDrives() As List(Of String)
        Dim usedDrives As New List(Of String)
        Try
            Dim p As New Process()
            p.StartInfo.FileName = "isocmd.exe"
            p.StartInfo.Arguments = "-print"
            p.StartInfo.UseShellExecute = False
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.CreateNoWindow = True

            p.Start()
            Dim output As String = p.StandardOutput.ReadToEnd()
            p.WaitForExit()

            ' Parse output isocmd -print
            ' Format baris biasanya: "E:  [mounted: C:\path\to\file.iso]" atau sejenisnya
            ' Kita juga cek lewat Windows: apakah drive letter ada isinya (bukan kosong)
            Dim lines() As String = output.Split(ControlChars.Lf)
            For Each line As String In lines
                line = line.Trim()
                ' Cari baris yang mengandung drive letter dan info mount
                ' Contoh output isocmd: "Drive E: -> C:\images\test.iso"
                ' atau "E: [ISO: C:\...]"
                If line.Length >= 2 Then
                    Dim letter As String = line.Substring(0, 1).ToUpper()
                    If letter >= "A" AndAlso letter <= "Z" Then
                        ' Jika baris mengandung path ISO (bukan hanya drive kosong)
                        If line.ToLower().Contains(".iso") OrElse
                           line.ToLower().Contains(".bin") OrElse
                           line.ToLower().Contains(".img") OrElse
                           line.ToLower().Contains(".nrg") OrElse
                           line.ToLower().Contains(".mds") OrElse
                           line.ToLower().Contains(".ccd") OrElse
                           line.ToLower().Contains("mounted") OrElse
                           line.ToLower().Contains("->") Then
                            If Not usedDrives.Contains(letter & ":") Then
                                usedDrives.Add(letter & ":")
                            End If
                        End If
                    End If
                End If
            Next

            ' Fallback: cek via Windows DriveInfo apakah virtual drive ada volume label "Virtual CD"
            ' atau ada media di dalamnya
            For Each di As IO.DriveInfo In IO.DriveInfo.GetDrives()
                If di.DriveType = IO.DriveType.CDRom Then
                    Try
                        If di.IsReady Then
                            Dim dl As String = di.Name.Substring(0, 2).ToUpper() ' "E:"
                            If Not usedDrives.Contains(dl) Then
                                usedDrives.Add(dl)
                            End If
                        End If
                    Catch
                        ' drive tidak siap, skip
                    End Try
                End If
            Next

        Catch ex As Exception
            ' silent fail
        End Try
        Return usedDrives
    End Function

    ''' <summary>
    ''' Dari daftar semua drive virtual yang tersedia, pilih drive pertama yang tidak sedang dipakai.
    ''' Jika semua dipakai, kembalikan Nothing.
    ''' </summary>
    Public Function GetFreeDrive(ByVal allDrives As List(Of String)) As String
        Dim used As List(Of String) = GetUsedDrives()
        For Each drv As String In allDrives
            If Not used.Contains(drv.ToUpper()) Then
                Return drv
            End If
        Next
        Return Nothing
    End Function

End Module
