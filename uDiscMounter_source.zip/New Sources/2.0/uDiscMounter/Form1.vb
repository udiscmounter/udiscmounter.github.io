Imports System.Diagnostics
Imports System.IO
Imports System.Drawing
Imports System.Security.Principal
Imports Microsoft.Win32
Public Class Form1
    Private Const MAX_USAGE As Integer = 50
    Private Const REG_PATH As String = "Software\ARImetic\uDiscMounter"
    Public maxusage As String
    Public remaining As String
    Private Sub statususage()

        Dim currentUsage As Integer = GetUsageCount()

        currentUsage += 1

        SaveUsageCount(currentUsage)

        ProgressBar1.Maximum = MAX_USAGE

        If currentUsage <= MAX_USAGE Then
            ProgressBar1.Value = MAX_USAGE - currentUsage
        Else
            ProgressBar1.Value = 0
        End If

        Dim remainingUsage As Integer = MAX_USAGE - currentUsage

        If remainingUsage < 0 Then
            remainingUsage = 0
        End If

        Label6.Text = "Remaining usage: " & _
                      remainingUsage.ToString() & _
                      "x / Current usage: " & _
                      currentUsage.ToString() & "x"

    End Sub
    Private Function GetUsageCount() As Integer

        Try

            Dim key As RegistryKey = Registry.CurrentUser.OpenSubKey(REG_PATH)

            If Not key Is Nothing Then

                Dim value As Object = key.GetValue("UsageCount", 0)

                key.Close()

                Return Convert.ToInt32(value)

            End If

        Catch
        End Try

        Return 0

    End Function

    Private Sub SaveUsageCount(ByVal count As Integer)

        Try

            Dim key As RegistryKey = Registry.CurrentUser.CreateSubKey(REG_PATH)

            key.SetValue("UsageCount", count, RegistryValueKind.DWord)

            key.Close()

        Catch
        End Try

    End Sub

    Private Function FormatSize(ByVal bytes As Long) As String
        Dim size As Double = bytes

        If size < 1024 Then
            Return size.ToString("0") & " B"
        End If

        size /= 1024
        If size < 1024 Then
            Return size.ToString("0.00") & " KB"
        End If

        size /= 1024
        If size < 1024 Then
            Return size.ToString("0.00") & " MB"
        End If

        size /= 1024
        If size < 1024 Then
            Return size.ToString("0.00") & " GB"
        End If

        size /= 1024
        Return size.ToString("0.00") & " TB"
    End Function
    Public Function GetSerialList() As String

        Return _
        "NKCR-KENU-II90" & vbCrLf & _
        "JY7H-4G69-RJHD" & vbCrLf & _
        "QN3I-Z319-BL01" & vbCrLf & _
        "8FBV-6JXA-6ZLR" & vbCrLf & _
        "SRUK-FK5E-DORT" & vbCrLf & _
        "N4FA-ZMO2-MPZ6" & vbCrLf & _
        "KULB-UA9S-FRIL" & vbCrLf & _
        "2LSO-1ZFU-B53B" & vbCrLf & _
        "MXC3-AQM7-8V8C" & vbCrLf & _
        "IBW3-325L-QVGP" & vbCrLf & _
        "P024-YGQL-AYZD" & vbCrLf & _
        "X0A8-W5NN-6BK4" & vbCrLf & _
        "0L2E-WFMI-VJZO" & vbCrLf & _
        "VZX5-GRWX-3KG1" & vbCrLf & _
        "2OT6-C4QN-NMQF" & vbCrLf & _
        "KP1J-JUNP-J0K6" & vbCrLf & _
        "4SKY-RLU2-QPHH" & vbCrLf & _
        "Z5EY-BXDQ-YQOK" & vbCrLf & _
        "XVAZ-7B8G-SS78" & vbCrLf & _
        "FVI2-D04I-NG2Y" & vbCrLf & _
        "ZY1R-MRCU-KWY0" & vbCrLf & _
        "UCWH-63V9-3W6D" & vbCrLf & _
        "11SI-1HPZ-NZPS"

    End Function
    Private Sub activationstatus()

        If Not IsActivated(GetSerialList) Then

            Button8.Enabled = True
            Button8.Text = "Activate"
            Button8.Image = My.Resources.foreign_key

            LinkLabel1.Text = "Add Virtual Drive *PRO"

            statususage()

            Me.Text = "uDiscMounter 26.1 Trial"
            Me.Icon = My.Resources.icon_trial

            ' Trial habis?
            If GetUsageCount() > MAX_USAGE Then

                MsgBox( _
                    "Your trial period has expired." & vbCrLf & _
                    "Please activate uDiscMounter to continue.", _
                    MsgBoxStyle.Exclamation, _
                    "Activation Required")

                frmActivate.Button4.Visible = False
                frmActivate.ShowDialog()

                ' Setelah form aktivasi ditutup, cek lagi
                If Not IsActivated(GetSerialList) Then

                    MsgBox( _
                        "Activation is required to continue using this software.", _
                        MsgBoxStyle.Critical, _
                        "Activation Required")

                    End
                    Exit Sub

                End If

                ' Berhasil aktivasi
                Button8.Enabled = False
                Button8.Text = "Active"
                Button8.Image = My.Resources.check_mark
                Label6.Visible = True
                ProgressBar1.Visible = True
                Me.Height = 414
                LinkLabel1.Text = "Add Virtual Drive"

                Me.Text = "uDiscMounter 26.1 Pro"
                Me.Icon = My.Resources.icon_pro

            End If

        Else

            Button8.Enabled = False
            Button8.Text = "Active"
            Button8.Image = My.Resources.check_mark
            Label6.Visible = False
            ProgressBar1.Visible = False
            Me.Height = 400
            LinkLabel1.Text = "Add Virtual Drive"

            Me.Text = "uDiscMounter 26.1 Pro"
            Me.Icon = My.Resources.icon_pro

        End If

    End Sub
    Private Function IsRunningAsAdmin() As Boolean
        Try
            Dim wi As WindowsIdentity = WindowsIdentity.GetCurrent()
            Dim wp As WindowsPrincipal = New WindowsPrincipal(wi)
            Return wp.IsInRole(WindowsBuiltInRole.Administrator)
        Catch
            Return False
        End Try
    End Function
    Private Sub AddFileToGrid(ByVal filePath As String)
        Try
            'ambil file info
            Dim fi As New FileInfo(filePath)

            'ambil icon file
            Dim icon As Icon = icon.ExtractAssociatedIcon(filePath)
            Dim bmp As Bitmap = icon.ToBitmap()

            'hitung size
            Dim sizeText As String = FormatSize(fi.Length)

            'tambah ke datagridview
            DataGridView1.Rows.Add(bmp, fi.Name, sizeText, fi.FullName)
            cekdrv()
            cekitem()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    ''' <summary>
    ''' Simpan daftar semua drive virtual (tanpa tanda) agar bisa dipakai GetFreeDrive.
    ''' </summary>
    Private _allDriveList As New List(Of String)

    Private Sub LoadIsoCmdDrives()
        ComboBox1.Items.Clear()
        _allDriveList.Clear()

        Try
            Dim p As New Process()
            p.StartInfo.FileName = "isocmd.exe"
            p.StartInfo.Arguments = "-print"
            p.StartInfo.UseShellExecute = False
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.CreateNoWindow = True

            p.Start()
            Dim output As String = p.StandardOutput.ReadToEnd()
            p.WaitForExit()

            Dim lines() As String = output.Split(ControlChars.Lf)

            For Each line As String In lines
                line = line.Trim()

                If line.Contains("DriveLetters=[") Then
                    Dim start As Integer = line.IndexOf("["c) + 1
                    Dim finish As Integer = line.IndexOf("]"c)

                    If start > 0 AndAlso finish > start Then
                        Dim inside As String = line.Substring(start, finish - start)
                        inside = inside.Trim()

                        Dim drives() As String

                        If inside.IndexOf(","c) >= 0 Then
                            ' Format: E,F,G
                            drives = inside.Split(","c)
                        Else
                            ' Format: EF  -> split per karakter tanpa LINQ
                            If inside.Length > 0 Then
                                ReDim drives(inside.Length - 1)
                                Dim i As Integer
                                For i = 0 To inside.Length - 1
                                    drives(i) = inside.Substring(i, 1)
                                Next
                            Else
                                ReDim drives(-1) ' kosong
                            End If
                        End If

                        Dim d As String
                        For Each d In drives
                            If d IsNot Nothing Then
                                d = d.Trim()
                                If d <> "" Then
                                    _allDriveList.Add(d & ":")
                                End If
                            End If
                        Next
                    End If
                End If
            Next

        Catch ex As Exception
            ' MessageBox.Show("Gagal menjalankan isocmd.exe -print" & vbCrLf & ex.Message)
        End Try

        ' Setelah daftar drive terkumpul, isi ComboBox dengan tanda "★ [USED]" bila terpakai
        RefreshDriveComboBox()
    End Sub

    ''' <summary>
    ''' Isi ulang ComboBox1 dengan status drive: normal atau "★ USED" bila sedang terpakai.
    ''' Otomatis pilih drive yang bebas.
    ''' </summary>
    Private Sub RefreshDriveComboBox()
        Dim usedDrives As List(Of String) = GetUsedDrives()
        ComboBox1.Items.Clear()

        Dim firstFreeIndex As Integer = -1
        Dim i As Integer = 0
        For Each drv As String In _allDriveList
            Dim drvUp As String = drv.ToUpper()
            If usedDrives.Contains(drvUp) Then
                ComboBox1.Items.Add(drvUp & " [Mounted]")
            Else
                ComboBox1.Items.Add(drvUp)
                If firstFreeIndex = -1 Then firstFreeIndex = i
            End If
            i += 1

        Next

        If firstFreeIndex >= 0 Then
            ComboBox1.SelectedIndex = firstFreeIndex
        ElseIf ComboBox1.Items.Count > 0 Then
            ComboBox1.SelectedIndex = 0
        End If
    End Sub

    ''' <summary>
    ''' Ambil drive letter bersih dari ComboBox (hapus tanda "★ [USED]" bila ada).
    ''' </summary>
    Private Function GetSelectedDriveLetter() As String
        If ComboBox1.SelectedItem Is Nothing Then Return ""
        Dim raw As String = ComboBox1.SelectedItem.ToString().Trim()
        ' Hapus suffix " ★ [USED]" jika ada
        Dim spaceIdx As Integer = raw.IndexOf(" ")
        If spaceIdx > 0 Then
            raw = raw.Substring(0, spaceIdx).Trim()
        End If
        Return raw
    End Function

    ''' <summary>
    ''' Tampilkan dialog konfirmasi mount ketika file dibuka via asosiasi.
    ''' Otomatis pilih drive bebas, kalau semua terpakai pakai drive pertama yang ada.
    ''' </summary>
    Private Sub ShowMountDialog(ByVal filePath As String)
        ' Refresh status drive dulu
        RefreshDriveComboBox()

        If ComboBox1.Items.Count = 0 Then
            MessageBox.Show("No virtual drives found. Please add a virtual drive first.", _
                            "No Virtual Drive", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim freeDrive As String = GetFreeDrive(_allDriveList)
        Dim targetDrive As String

        If freeDrive Is Nothing Then
            ' Semua drive sedang dipakai — pakai drive pertama dari daftar
            targetDrive = _allDriveList(0)
            Dim msg As String = "All virtual drives are currently in use." & vbCrLf & vbCrLf & _
                                "File: " & IO.Path.GetFileName(filePath) & vbCrLf & _
                                "Drive: " & targetDrive & " (will replace current mount)" & vbCrLf & vbCrLf & _
                                "Mount to " & targetDrive & "?"
            Dim res As DialogResult = MessageBox.Show(msg, "Mount Image - All Drives Busy", _
                                                      MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
            If res = DialogResult.No Then Return
        Else
            targetDrive = freeDrive
            Dim msg As String = "Mount this image?" & vbCrLf & vbCrLf & _
                                "File : " & IO.Path.GetFileName(filePath) & vbCrLf & _
                                "Drive: " & targetDrive
            Dim res As DialogResult = MessageBox.Show(msg, "Mount Image", _
                                                      MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If res = DialogResult.No Then Return
        End If

        ' Set ComboBox ke targetDrive
        For idx As Integer = 0 To ComboBox1.Items.Count - 1
            Dim item As String = ComboBox1.Items(idx).ToString()
            If item.StartsWith(targetDrive.ToUpper()) OrElse item.StartsWith(targetDrive) Then
                ComboBox1.SelectedIndex = idx
                Exit For
            End If
        Next

        ' Mount
        TextBox1.Text = filePath
        Dim result As String = MountISO(targetDrive, filePath)
        Process.Start(targetDrive)

        ' Refresh tampilan ComboBox setelah mount
        RefreshDriveComboBox()
    End Sub

    Private Sub Form1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragDrop
        Try
            Dim files() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())

            ' Daftar ekstensi valid
            Dim allowedExt() As String = {".iso", ".bin", ".img", ".cif", ".nrg",
                                          ".mds", ".ccd", ".bwi", ".isz", ".dmg",
                                          ".daa", ".uif", ".hfs"}

            For Each f As String In files

                Dim ext As String = LCase(System.IO.Path.GetExtension(f))

                ' CEK EKSTENSI
                If Array.IndexOf(allowedExt, ext) = -1 Then
                    MessageBox.Show("Format not supported: " & f)
                    Continue For
                End If

                ' CEK DUPLIKAT
                Dim isDuplicate As Boolean = False
                For Each row As DataGridViewRow In DataGridView1.Rows
                    If row.Cells(3).Value IsNot Nothing Then
                        If row.Cells(3).Value.ToString().ToLower() = f.ToLower() Then
                            isDuplicate = True
                            Exit For
                        End If
                    End If
                Next

                If isDuplicate Then
                    MessageBox.Show("The file already exists in the list: " & f)
                    Continue For
                End If

                ' Jika lolos → masukkan
                AddFileToGrid(f)
            Next

            cekitem()

        Catch ex As Exception
            MessageBox.Show("Drag & Drop Error: " & ex.Message)
        End Try
    End Sub

    Private Sub Form1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Sub cekdrv()
        If ComboBox1.Items.Count > 0 Then
            ComboBox1.Enabled = True
            LinkLabel1.Enabled = True
            If AdaItem() Then
                Button2.Enabled = True
                Button3.Enabled = True
            Else
                Button2.Enabled = False
                Button3.Enabled = False
            End If
        Else
            ComboBox1.Enabled = False
            LinkLabel1.Enabled = False
            Button2.Enabled = False
            Button3.Enabled = False
        End If
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Icon = My.Resources.icon_trial
        CheckFileAssociationArgs()
        LoadIsoCmdDrives()
        cekdrv()
        activationstatus()
        If StartupFile IsNot Nothing Then
            ' File dibuka via asosiasi — tampilkan dialog mount langsung
            cekdrv()
            AddFileToGrid(StartupFile)
            Button5.Enabled = True
            Panel1.Visible = False
            TextBox1.Text = StartupFile
            ' Tampilkan dialog mount otomatis
            ShowMountDialog(StartupFile)
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.ActiveControl = Nothing
        Dim dlg As New OpenFileDialog()
        dlg.Multiselect = True

        ' Filter optional (boleh dipakai atau tidak)
        dlg.Filter = "Disc Image Files|*.iso;*.bin;*.img;*.cif;*.nrg;*.mds;*.ccd;*.bwi;*.isz;*.dmg;*.daa;*.uif;*.hfs"

        If dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then

            ' Daftar ekstensi yang diperbolehkan (lowercase semua)
            Dim allowedExt() As String = {".iso", ".bin", ".img", ".cif", ".nrg", _
                                          ".mds", ".ccd", ".bwi", ".isz", ".dmg", _
                                          ".daa", ".uif", ".hfs"}

            For Each f As String In dlg.FileNames

                Dim ext As String = LCase(System.IO.Path.GetExtension(f))

                ' CEK FORMAT TIDAK DIDUKUNG
                If Array.IndexOf(allowedExt, ext) = -1 Then
                    MessageBox.Show("Format tidak didukung: " & f)
                    Continue For
                End If

                ' CEK DUPLIKAT (CEK File Path dalam DataGridView)
                Dim isDuplicate As Boolean = False

                For Each row As DataGridViewRow In DataGridView1.Rows
                    If row.Cells(3).Value IsNot Nothing Then
                        If row.Cells(3).Value.ToString().ToLower() = f.ToLower() Then
                            isDuplicate = True
                            Exit For
                        End If
                    End If
                Next

                If isDuplicate Then
                    MessageBox.Show("The file already exists in the list: " & f)
                    Continue For
                End If

                ' Jika lolos semua → tambahkan ke grid
                AddFileToGrid(f)
                cekitem()
                cekdrv()
            Next
        End If
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim row As DataGridViewRow = DataGridView1.SelectedRows(0)
            TextBox1.Text = row.Cells(3).Value.ToString()
            cekdrv()
            Button4.Enabled = True
        Else
            Button2.Enabled = False
            Button3.Enabled = False
            Button4.Enabled = False
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim row As DataGridViewRow = DataGridView1.SelectedRows(0)
            TextBox1.Text = row.Cells(3).Value.ToString()
            cekdrv()
            Button4.Enabled = True
        Else
            Button2.Enabled = False
            Button3.Enabled = False
            Button4.Enabled = False
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.ActiveControl = Nothing

        ' Ambil drive bersih dari ComboBox (tanpa tanda ★)
        Dim drive As String = GetSelectedDriveLetter()
        Dim iso As String = TextBox1.Text

        ' Cek apakah drive yang dipilih sedang dipakai
        Dim usedDrives As List(Of String) = GetUsedDrives()
        If usedDrives.Contains(drive.ToUpper()) Then
            Dim freeDrive As String = GetFreeDrive(_allDriveList)
            If freeDrive IsNot Nothing Then
                ' Ada drive lain yang bebas — tawarkan pindah
                Dim msg As String = "Drive " & drive & " is currently in use." & vbCrLf & _
                                    "Switch to free drive " & freeDrive & " instead?"
                Dim res As DialogResult = MessageBox.Show(msg, "Drive In Use", _
                                                          MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If res = DialogResult.Yes Then
                    drive = freeDrive
                    ' Update selection di ComboBox
                    For idx As Integer = 0 To ComboBox1.Items.Count - 1
                        If ComboBox1.Items(idx).ToString().StartsWith(freeDrive) Then
                            ComboBox1.SelectedIndex = idx
                            Exit For
                        End If
                    Next
                End If
            Else
                ' Semua drive terpakai
                Dim res As DialogResult = MessageBox.Show("Drive " & drive & " is in use and all other drives are busy." & vbCrLf & _
                                                           "Mount anyway (will replace current)?", _
                                                           "All Drives Busy", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
                If res = DialogResult.No Then Return
            End If
        End If

        Dim result As String = MountISO(drive, iso)
        Process.Start(drive)

        ' Refresh ComboBox setelah mount
        RefreshDriveComboBox()
        cekdrv()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.ActiveControl = Nothing
        Dim drive As String = GetSelectedDriveLetter()
        Dim result As String = EjectISO(drive)
        ' Refresh ComboBox setelah eject
        RefreshDriveComboBox()
        cekdrv()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        If LinkLabel1.Text = "Add Virtual Drive" Then
            VirtualDrive.ShowDialog()
            ' Reload drives setelah tambah virtual drive baru
            LoadIsoCmdDrives()
            cekdrv()
        Else
            MsgBox("This feature can only be used in the pro version", vbExclamation, "Trial Version")
        End If

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For Each row As DataGridViewRow In DataGridView1.SelectedRows
                DataGridView1.Rows.Remove(row)
            Next
            cekitem()
        Else
            '
        End If
    End Sub
    Private Function AdaItem() As Boolean
        Return DataGridView1.Rows.Count > 0
    End Function
    Private Sub cekitem()
        If AdaItem() Then
            Panel1.Visible = False
            Button5.Enabled = True
        Else
            Button5.Enabled = False
            Panel1.Visible = True
        End If
    End Sub
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        DataGridView1.Rows.Clear()
        cekitem()
    End Sub

    Private Sub OpenFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFileToolStripMenuItem.Click
        Button1.PerformClick()
    End Sub

    Private Sub MountToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MountToolStripMenuItem.Click
        Button2.PerformClick()
    End Sub

    Private Sub EjectToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EjectToolStripMenuItem.Click
        Button3.PerformClick()
    End Sub

    Private Sub DelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DelToolStripMenuItem.Click
        Button4.PerformClick()
    End Sub

    Private Sub ClearToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripMenuItem.Click
        Button5.PerformClick()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Me.ActiveControl = Nothing
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Me.ActiveControl = Nothing
        Try
            Process.Start("https://udiscmounter.github.io/content/")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Me.ActiveControl = Nothing
        If Button8.Enabled = True Then
            frmAbout.lbstatus.Text = "<Trial Version>"
            frmAbout.lbstatus.ForeColor = Color.Red
        Else
            frmAbout.lbstatus.Text = "<Pro Version>"
            frmAbout.lbstatus.ForeColor = Color.Blue
        End If
        frmAbout.ShowDialog()
    End Sub

    Private Sub DelToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DelToolStripMenuItem1.Click
        Button4.PerformClick()
    End Sub

    Private Sub ClearToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripMenuItem1.Click
        Button5.PerformClick()
    End Sub


    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            Me.TopMost = True
        Else
            Me.TopMost = False
        End If
    End Sub

    Private Sub CheckBox1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox1.MouseEnter
        CheckBox1.ForeColor = Color.Firebrick
    End Sub

    Private Sub CheckBox1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox1.MouseLeave
        CheckBox1.ForeColor = Color.Black
    End Sub

    Private Sub HelpToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpToolStripMenuItem.Click
        Button6.PerformClick()
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub PictureBox1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox1.MouseEnter
        PictureBox1.Image = My.Resources.comp2
    End Sub

    Private Sub PictureBox1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox1.MouseLeave
        PictureBox1.Image = My.Resources.comp1
    End Sub

    Private Sub PictureBox4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox4.Click

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        frmActivate.Button4.Visible = False
        frmActivate.ShowDialog()
    End Sub
End Class
