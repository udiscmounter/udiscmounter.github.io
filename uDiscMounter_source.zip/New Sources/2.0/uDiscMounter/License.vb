﻿Imports System.IO

Module License

    Public Function IsActivated(ByVal daftarSerial As String) As Boolean

        Dim pathKey As String = Application.StartupPath & "\reg.key"

        If Not File.Exists(pathKey) Then
            Return False
        End If

        Dim serialTersimpan As String = _
            UCase(Trim(File.ReadAllText(pathKey)))

        If serialTersimpan = "" Then
            Return False
        End If

        Dim daftar() As String = daftarSerial.Replace(vbCrLf, vbLf).Split(ControlChars.Lf)

        Dim i As Integer

        For i = 0 To daftar.Length - 1

            If UCase(Trim(daftar(i))) = serialTersimpan Then
                Return True
            End If

        Next

        Return False

    End Function

End Module