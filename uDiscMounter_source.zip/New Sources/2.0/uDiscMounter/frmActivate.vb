﻿Imports System.IO
Public Class frmActivate

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.ActiveControl = Nothing
        Process.Start("https://www.paypal.com/ncp/payment/FQRQBXHRNTML4")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.ActiveControl = Nothing
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.ActiveControl = Nothing
        Dim serialCari As String
        Dim daftar() As String
        Dim i As Integer
        Dim ditemukan As Boolean

        serialCari = Trim(TextBox1.Text)

        daftar = Split(TextBox2.Text, vbCrLf)

        For i = 0 To UBound(daftar)

            If UCase(Trim(daftar(i))) = UCase(serialCari) Then
                ditemukan = True
                Exit For
            End If

        Next

        If ditemukan Then

            Dim pathKey As String
            pathKey = Application.StartupPath & "\reg.key"

            File.WriteAllText(pathKey, serialCari)

            MsgBox("Activation successful!" & vbNewLine & "Now you can use uDiscMounter without limits.", vbExclamation)

            Application.Restart()

        Else

            MsgBox("Serial Number is incorrect!" & vbNewLine & "Please contact the developer, or if you don't have a serial number, please purchase one by pressing the Buy Now button in the activation dialog.", vbCritical)
            TextBox1.Clear()
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Form1.Show()
        Me.Close()
    End Sub
End Class