; ========================================================
; uDiscMounter Installer (CLASSIC RETRO UI – FINAL BUILD)
; ========================================================

!include "LogicLib.nsh"
!include "WinVer.nsh"
!include "MUI2.nsh"

!define APPNAME "uDiscMounter"
!define VERSION "25.1"

OutFile "uDiscMounter_x86_x64.exe"
InstallDir "$PROGRAMFILES\${APPNAME}"

Var ProgramFolder

; ========================================================
; CLASSIC RETRO UI DESIGN
; ========================================================

!define MUI_ICON               "InstallerAssets\setup.ico"
!define MUI_UNICON             "InstallerAssets\uninstall.ico"

!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_BITMAP "InstallerAssets\header.bmp"
!define MUI_HEADERIMAGE_RIGHT

!define MUI_WELCOMEFINISHPAGE_BITMAP "InstallerAssets\sidebar.bmp"
!define MUI_UNWELCOMEFINISHPAGE_BITMAP "InstallerAssets\sidebar.bmp"

!define MUI_ABORTWARNING

; Title bar
Caption "${APPNAME} Professional Installer"

BrandingText "Copyright (c) 2015 - 2025 Ari Project. All Rights Reserved."

; Progress bar classic
InstProgressFlags smooth

; ========================================================
; PAGES
; ========================================================

!insertmacro MUI_PAGE_LICENSE "2.0\eula.txt"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES

!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_TEXT "Run uDiscMounter"
!define MUI_FINISHPAGE_RUN_FUNCTION LaunchApp
!insertmacro MUI_PAGE_FINISH

; --- Uninstaller ---
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

; ========================================================
; OS Detection
; ========================================================

Function DetectOS
    StrCpy $ProgramFolder ""

    ${If} ${AtLeastWin8}
        StrCpy $ProgramFolder "4.0"
        Return
    ${EndIf}

    ${If} ${AtLeastWinVista}
        StrCpy $ProgramFolder "2.0"
        Return
    ${EndIf}

    StrCpy $ProgramFolder ""
FunctionEnd

; ========================================================
; Internal Sections
; ========================================================

Section "-Core2_0" SEC20
    SetOutPath "$INSTDIR"
    File "2.0\uDiscMounter.exe"
SectionEnd

Section "-Core4_0" SEC40
    SetOutPath "$INSTDIR"
    File "4.0\uDiscMounter.exe"
SectionEnd

; ========================================================
; INSTALL SECTION
; ========================================================

Section "Install"

    Call DetectOS

    ${If} $ProgramFolder == ""
        MessageBox MB_ICONSTOP "Windows version not supported!"
        Quit
    ${EndIf}

    ${If} $ProgramFolder == "2.0"
        SectionSetFlags ${SEC20} 1
        SectionSetFlags ${SEC40} 0
    ${Else}
        SectionSetFlags ${SEC20} 0
        SectionSetFlags ${SEC40} 1
    ${EndIf}

    ; Drivers
    SetOutPath "$WINDIR"
    File "Driver\IsoCmd.exe"
    File "Driver\ISODrive.sys"
    File "Driver\ISODrv64.sys"

    nsExec::ExecToLog '"$WINDIR\IsoCmd.exe" -install'

    ; Desktop shortcut
    CreateShortcut "$DESKTOP\uDiscMounter.lnk" "$INSTDIR\uDiscMounter.exe"

    ; File associations
    WriteRegStr HKCR ".iso" "" "uDiscMounterFile"
    WriteRegStr HKCR ".img" "" "uDiscMounterFile"
    WriteRegStr HKCR ".bin" "" "uDiscMounterFile"
    WriteRegStr HKCR ".cue" "" "uDiscMounterFile"
    WriteRegStr HKCR ".mdf" "" "uDiscMounterFile"
    WriteRegStr HKCR ".mds" "" "uDiscMounterFile"
    WriteRegStr HKCR ".nrg" "" "uDiscMounterFile"
    WriteRegStr HKCR ".uif" "" "uDiscMounterFile"
    WriteRegStr HKCR ".daa" "" "uDiscMounterFile"

    WriteRegStr HKCR "uDiscMounterFile\shell\open\command" "" '"$INSTDIR\uDiscMounter.exe" "%1"'

    ; Uninstaller
    WriteUninstaller "$INSTDIR\Uninstall.exe"

SectionEnd

; ========================================================
; UNINSTALL
; ========================================================

Section "Uninstall"

    nsExec::ExecToLog '"$WINDIR\IsoCmd.exe" -remove'

    Delete "$WINDIR\IsoCmd.exe"
    Delete "$WINDIR\ISODrive.sys"
    Delete "$WINDIR\ISODrv64.sys"

    Delete "$DESKTOP\uDiscMounter.lnk"

    DeleteRegKey HKCR ".iso"
    DeleteRegKey HKCR ".img"
    DeleteRegKey HKCR ".bin"
    DeleteRegKey HKCR ".cue"
    DeleteRegKey HKCR ".mdf"
    DeleteRegKey HKCR ".mds"
    DeleteRegKey HKCR ".nrg"
    DeleteRegKey HKCR ".uif"
    DeleteRegKey HKCR ".daa"
    DeleteRegKey HKCR "uDiscMounterFile"

    Delete "$INSTDIR\uDiscMounter.exe"
    Delete "$INSTDIR\Uninstall.exe"

    RMDir "$INSTDIR"
SectionEnd


Function LaunchApp
    Exec '"$INSTDIR\uDiscMounter.exe"'
FunctionEnd
