﻿Imports System.Diagnostics

Public Class VirtualDrive

    Private Sub VirtualDrive_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        NumericUpDown1.Value = Form1.ComboBox1.Items.Count
        If NumericUpDown1.Value = Form1.ComboBox1.Items.Count Then
            Button1.Enabled = False
        Else
            Button1.Enabled = True
        End If
    End Sub

    Private Sub RunIsoNumber()
        Try
            Dim angka As Integer = NumericUpDown1.Value
            Dim result As String = SetDriveCount(angka)

            If result = "" Then
                MessageBox.Show("The operation has completed successfully." & vbCrLf & _
                                "Please restart your computer to apply the changes.", _
                                "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Me.Close()
            Else
                MessageBox.Show(result, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MessageBox.Show("Failed to execute the command." & vbCrLf & ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        RunIsoNumber()
    End Sub

    Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged
        If NumericUpDown1.Value = Form1.ComboBox1.Items.Count Then
            Button1.Enabled = False
        Else
            Button1.Enabled = True
        End If
    End Sub
End Class