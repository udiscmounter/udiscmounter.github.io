Imports System.Diagnostics
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Windows.Forms
Imports System.Reflection

Public Class Form1

    Private _loadingGrid As Boolean = False
    Private WithEvents _autoCheckTimer As System.Windows.Forms.Timer
    Private _iconList As New ImageList()
    Private _headerFont As Font
    Private _hoverIndex As Integer = -1

    Private Function GetGridCachePath() As String
        Dim dir As String = System.IO.Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "uDiscMounter")
        If Not Directory.Exists(dir) Then
            Try
                Directory.CreateDirectory(dir)
            Catch
            End Try
        End If
        Return System.IO.Path.Combine(dir, "gridlist.dat")
    End Function

    Private Sub SaveGridList()
        If _loadingGrid Then Return
        Try
            Dim lines As New List(Of String)
            For Each item As ListViewItem In ListView1.Items
                If item.SubItems.Count >= 3 Then
                    lines.Add(item.SubItems(2).Text)
                End If
            Next
            File.WriteAllLines(GetGridCachePath(), lines.ToArray())
        Catch
        End Try
    End Sub

    Private Function FormatSize(ByVal bytes As Long) As String
        Dim size As Double = bytes

        If size < 1024 Then
            Return size.ToString("0") & " B"
        End If

        size /= 1024
        If size < 1024 Then
            Return size.ToString("0.00") & " KB"
        End If

        size /= 1024
        If size < 1024 Then
            Return size.ToString("0.00") & " MB"
        End If

        size /= 1024
        If size < 1024 Then
            Return size.ToString("0.00") & " GB"
        End If

        size /= 1024
        Return size.ToString("0.00") & " TB"
    End Function

    Private Sub SetDoubleBuffered(ByVal ctrl As Control)
        Try
            Dim prop As PropertyInfo = GetType(Control).GetProperty("DoubleBuffered", _
                BindingFlags.Instance Or BindingFlags.NonPublic)
            If prop IsNot Nothing Then
                prop.SetValue(ctrl, True, Nothing)
            End If
        Catch
        End Try
    End Sub

    Private Sub InitializeListView()
        ListView1.View = View.Details
        ListView1.FullRowSelect = True
        ListView1.GridLines = False
        ListView1.MultiSelect = True
        ListView1.HideSelection = False
        ListView1.LabelEdit = False
        ListView1.HeaderStyle = ColumnHeaderStyle.Nonclickable
        ListView1.BorderStyle = BorderStyle.None
        ListView1.BackColor = Color.White
        ListView1.ForeColor = Color.Black
        ListView1.Font = New Font("Tahoma", 9, FontStyle.Regular)
        ListView1.OwnerDraw = True

        SetDoubleBuffered(ListView1)

        ListView1.Columns.Clear()
        ListView1.Columns.Add("Name", 220, HorizontalAlignment.Left)
        ListView1.Columns.Add("Size", 90, HorizontalAlignment.Right)
        ListView1.Columns.Add("Path", 320, HorizontalAlignment.Left)

        _iconList.ImageSize = New Size(16, 16)
        _iconList.ColorDepth = ColorDepth.Depth32Bit
        ListView1.SmallImageList = _iconList

        If _headerFont IsNot Nothing Then _headerFont.Dispose()
        _headerFont = New Font(ListView1.Font, FontStyle.Regular)

        AutoSizeListViewColumns()
    End Sub

    Private Sub AutoSizeListViewColumns()
        If ListView1.Columns.Count < 3 Then Return

        Dim totalWidth As Integer = ListView1.ClientSize.Width
        Dim nameWidth As Integer = CInt(totalWidth * 0.35)
        Dim sizeWidth As Integer = CInt(totalWidth * 0.15)
        Dim pathWidth As Integer = totalWidth - nameWidth - sizeWidth - 25

        If nameWidth < 120 Then nameWidth = 120
        If sizeWidth < 70 Then sizeWidth = 70
        If pathWidth < 120 Then pathWidth = 120

        ListView1.Columns(0).Width = nameWidth
        ListView1.Columns(1).Width = sizeWidth
        ListView1.Columns(2).Width = pathWidth
    End Sub

    Private Sub ListView1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView1.Resize
        AutoSizeListViewColumns()
    End Sub

    Private Sub Form1_ResizeEnd(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.ResizeEnd
        AutoSizeListViewColumns()
    End Sub

    Private Sub ListView1_DrawColumnHeader(ByVal sender As Object, ByVal e As DrawListViewColumnHeaderEventArgs) Handles ListView1.DrawColumnHeader
        If _headerFont Is Nothing Then
            _headerFont = New Font(ListView1.Font, FontStyle.Regular)
        End If

        Dim g As Graphics = e.Graphics
        g.SmoothingMode = SmoothingMode.None

        Using lg As New LinearGradientBrush(e.Bounds, _
                                            Color.White, _
                                            Color.FromArgb(200, 218, 244), _
                                            LinearGradientMode.Vertical)
            g.FillRectangle(lg, e.Bounds)
        End Using

        Using p As New Pen(Color.FromArgb(172, 191, 224))
            g.DrawLine(p, e.Bounds.Left, e.Bounds.Bottom - 1, e.Bounds.Right, e.Bounds.Bottom - 1)
            If e.ColumnIndex > 0 Then
                g.DrawLine(p, e.Bounds.Left, e.Bounds.Top + 3, e.Bounds.Left, e.Bounds.Bottom - 4)
            End If
        End Using

        Using p As New Pen(Color.White)
            g.DrawLine(p, e.Bounds.Left, e.Bounds.Top, e.Bounds.Right, e.Bounds.Top)
            If e.ColumnIndex > 0 Then
                g.DrawLine(p, e.Bounds.Left + 1, e.Bounds.Top + 3, e.Bounds.Left + 1, e.Bounds.Bottom - 4)
            End If
        End Using

        Dim rect As Rectangle = e.Bounds
        rect.X += 6
        rect.Width -= 10

        Dim flags As TextFormatFlags = TextFormatFlags.VerticalCenter Or TextFormatFlags.EndEllipsis Or TextFormatFlags.NoPrefix
        If e.Header.TextAlign = HorizontalAlignment.Right Then
            flags = flags Or TextFormatFlags.Right
        Else
            flags = flags Or TextFormatFlags.Left
        End If

        TextRenderer.DrawText(g, e.Header.Text, _headerFont, rect, _
                              Color.Black, flags)
    End Sub

    Private Sub ListView1_DrawItem(ByVal sender As Object, ByVal e As DrawListViewItemEventArgs) Handles ListView1.DrawItem
        Dim back As Color

        If e.Item.Selected Then
            If ListView1.Focused Then
                back = Color.FromArgb(49, 106, 197)
            Else
                back = Color.FromArgb(222, 230, 247)
            End If
        ElseIf e.ItemIndex = _hoverIndex Then
            back = Color.FromArgb(233, 240, 252)
        Else
            back = Color.White
        End If

        Using b As New SolidBrush(back)
            e.Graphics.FillRectangle(b, e.Bounds)
        End Using
    End Sub

    Private Sub ListView1_DrawSubItem(ByVal sender As Object, ByVal e As DrawListViewSubItemEventArgs) Handles ListView1.DrawSubItem
        Dim textColor As Color
        If e.Item.Selected AndAlso ListView1.Focused Then
            textColor = Color.White
        Else
            textColor = Color.Black
        End If

        Dim rect As Rectangle = e.Bounds
        Dim flags As TextFormatFlags = TextFormatFlags.VerticalCenter Or TextFormatFlags.EndEllipsis Or TextFormatFlags.NoPrefix

        If e.ColumnIndex = 0 Then
            rect.X += 6
            rect.Width -= 10

            If e.Item.ImageIndex >= 0 AndAlso ListView1.SmallImageList IsNot Nothing Then
                If e.Item.ImageIndex < ListView1.SmallImageList.Images.Count Then
                    Dim img As Image = ListView1.SmallImageList.Images(e.Item.ImageIndex)
                    If img IsNot Nothing Then
                        Dim imgY As Integer = e.Bounds.Y + (e.Bounds.Height - 16) \ 2
                        e.Graphics.DrawImage(img, e.Bounds.X + 4, imgY, 16, 16)
                        rect.X += 20
                        rect.Width -= 20
                    End If
                End If
            End If

            flags = flags Or TextFormatFlags.Left

        ElseIf e.ColumnIndex = 1 Then
            flags = flags Or TextFormatFlags.Right
            rect.Width -= 10

        Else
            flags = flags Or TextFormatFlags.Left
            rect.X += 6
            rect.Width -= 10
        End If

        TextRenderer.DrawText(e.Graphics, e.SubItem.Text, ListView1.Font, rect, textColor, flags)
    End Sub

    Private Sub ListView1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles ListView1.MouseMove
        Dim hit As ListViewHitTestInfo = ListView1.HitTest(e.Location)
        Dim newHover As Integer = -1
        If hit IsNot Nothing AndAlso hit.Item IsNot Nothing Then
            newHover = hit.Item.Index
        End If

        If newHover <> _hoverIndex Then
            _hoverIndex = newHover
            ListView1.Invalidate()
        End If
    End Sub

    Private Sub ListView1_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles ListView1.MouseLeave
        If _hoverIndex <> -1 Then
            _hoverIndex = -1
            ListView1.Invalidate()
        End If
    End Sub

    Private Sub AddFileToList(ByVal filePath As String)
        Try
            Dim fi As New FileInfo(filePath)

            Dim ico As Icon = Icon.ExtractAssociatedIcon(filePath)
            Dim bmp As Bitmap = ico.ToBitmap()

            _iconList.Images.Add(bmp)
            Dim imgIdx As Integer = _iconList.Images.Count - 1

            Dim sizeText As String = FormatSize(fi.Length)

            Dim item As New ListViewItem(fi.Name, imgIdx)
            item.SubItems.Add(sizeText)
            item.SubItems.Add(fi.FullName)
            item.Tag = fi.FullName

            ListView1.Items.Add(item)

            cekdrv()
            cekitem()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub RemoveFileFromList(ByVal fullPath As String)
        For i As Integer = ListView1.Items.Count - 1 To 0 Step -1
            Dim item As ListViewItem = ListView1.Items(i)
            If item.SubItems.Count >= 3 Then
                If item.SubItems(2).Text.ToLower() = fullPath.ToLower() Then
                    ListView1.Items.RemoveAt(i)
                End If
            End If
        Next
    End Sub

    Private Function FindItemByPath(ByVal fullPath As String) As ListViewItem
        For Each item As ListViewItem In ListView1.Items
            If item.SubItems.Count >= 3 Then
                If item.SubItems(2).Text.ToLower() = fullPath.ToLower() Then
                    Return item
                End If
            End If
        Next
        Return Nothing
    End Function

    Private _allDriveList As New List(Of String)

    Private Sub LoadIsoCmdDrives()
        ComboBox1.Items.Clear()
        _allDriveList.Clear()

        _allDriveList = GetAllVirtualDrives()
        RefreshDriveComboBox()
    End Sub

    Private Sub RefreshDriveComboBox()
        Dim usedDrives As List(Of String) = GetUsedDrives()
        Dim mountedFiles As Dictionary(Of String, String) = GetMountedFiles()
        ComboBox1.Items.Clear()

        Dim firstFreeIndex As Integer = -1
        Dim i As Integer = 0
        For Each drv As String In _allDriveList
            Dim drvUp As String = drv.ToUpper()
            If usedDrives.Contains(drvUp) Then
                Dim display As String
                If mountedFiles.ContainsKey(drvUp) Then
                    Dim isoPath As String = mountedFiles(drvUp)
                    If File.Exists(isoPath) Then
                        display = drvUp & "/" & System.IO.Path.GetFileName(isoPath)
                    Else
                        display = drvUp & "/[Mounted]"
                    End If
                Else
                    display = drvUp & "/[Mounted]"
                End If
                ComboBox1.Items.Add(display)
            Else
                ComboBox1.Items.Add(drvUp)
                If firstFreeIndex = -1 Then firstFreeIndex = i
            End If
            i += 1
        Next

        If firstFreeIndex >= 0 Then
            ComboBox1.SelectedIndex = firstFreeIndex
        ElseIf ComboBox1.Items.Count > 0 Then
            ComboBox1.SelectedIndex = 0
        End If
    End Sub

    Private Function GetSelectedDriveLetter() As String
        If ComboBox1.SelectedItem Is Nothing Then Return ""
        Dim raw As String = ComboBox1.SelectedItem.ToString().Trim()

        Dim slashIdx As Integer = raw.IndexOf("/")
        Dim spaceIdx As Integer = raw.IndexOf(" ")

        Dim cutIdx As Integer = -1
        If slashIdx >= 0 AndAlso spaceIdx >= 0 Then
            If slashIdx < spaceIdx Then
                cutIdx = slashIdx
            Else
                cutIdx = spaceIdx
            End If
        ElseIf slashIdx >= 0 Then
            cutIdx = slashIdx
        ElseIf spaceIdx >= 0 Then
            cutIdx = spaceIdx
        End If

        If cutIdx > 0 Then
            raw = raw.Substring(0, cutIdx).Trim()
        End If

        If Not raw.EndsWith(":") Then raw &= ":"
        Return raw
    End Function

    Private Sub ShowMountDialog(ByVal filePath As String)
        RefreshDriveComboBox()

        If ComboBox1.Items.Count = 0 Then
            MessageBox.Show("No virtual drives found. Please add a virtual drive first.", _
                            "No Virtual Drive", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim freeDrive As String = GetFreeDrive(_allDriveList)
        Dim targetDrive As String

        If freeDrive Is Nothing Then
            targetDrive = _allDriveList(0)
            Dim msg As String = "All virtual drives are currently in use." & vbCrLf & vbCrLf & _
                                "File: " & IO.Path.GetFileName(filePath) & vbCrLf & _
                                "Drive: " & targetDrive & " (will replace current mount)" & vbCrLf & vbCrLf & _
                                "Mount to " & targetDrive & "?"
            Dim res As DialogResult = MessageBox.Show(msg, "Mount Image - All Drives Busy", _
                                                      MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
            If res = DialogResult.No Then Return
        Else
            targetDrive = freeDrive
            Dim msg As String = "Mount this image?" & vbCrLf & vbCrLf & _
                                "File : " & IO.Path.GetFileName(filePath) & vbCrLf & _
                                "Drive: " & targetDrive
            Dim res As DialogResult = MessageBox.Show(msg, "Mount Image", _
                                                      MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If res = DialogResult.No Then Return
        End If

        For idx As Integer = 0 To ComboBox1.Items.Count - 1
            Dim item As String = ComboBox1.Items(idx).ToString()
            If item.StartsWith(targetDrive.ToUpper()) OrElse item.StartsWith(targetDrive) Then
                ComboBox1.SelectedIndex = idx
                Exit For
            End If
        Next

        TextBox1.Text = filePath
        MountISO(targetDrive, filePath)
        Process.Start(targetDrive)

        RefreshDriveComboBox()
        ShellIntegration.RefreshShellMenu()
    End Sub

    Private Sub Form1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragDrop
        Try
            Dim files() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())

            Dim allowedExt() As String = {".iso", ".bin", ".img", ".cif", ".nrg",
                                          ".mds", ".ccd", ".bwi", ".isz", ".dmg",
                                          ".daa", ".uif", ".hfs"}

            For Each f As String In files
                Dim ext As String = LCase(System.IO.Path.GetExtension(f))

                If Array.IndexOf(allowedExt, ext) = -1 Then
                    MessageBox.Show("Format not supported: " & f)
                    Continue For
                End If

                If FindItemByPath(f) IsNot Nothing Then
                    MessageBox.Show("The file already exists in the list: " & f)
                    Continue For
                End If

                AddFileToList(f)
            Next

            cekitem()
            cekdrv()
            SaveGridList()

        Catch ex As Exception
            MessageBox.Show("Drag & Drop Error: " & ex.Message)
        End Try
    End Sub

    Private Sub Form1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Sub cekdrv()
        Dim adaFile As Boolean = ListView1.Items.Count > 0
        Dim adaDrive As Boolean = ComboBox1.Items.Count > 0

        If adaDrive Then
            ComboBox1.Enabled = True
            LinkLabel1.Enabled = True
        Else
            ComboBox1.Enabled = False
            LinkLabel1.Enabled = False
        End If

        If adaFile AndAlso adaDrive Then
            Button2.Enabled = True
            Button3.Enabled = True
        Else
            Button2.Enabled = False
            Button3.Enabled = False
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ResourceExtractor.ExtractResources()

        InitializeListView()

        Me.MinimumSize = New Size(576, 442)

        Me.Text = "uDiscMounter 26.2"
        Me.Icon = My.Resources.head_logo

        CheckFileAssociationArgs()
        LoadIsoCmdDrives()
        cekdrv()

        _loadingGrid = True
        Try
            Dim rawMounted As Dictionary(Of String, String) = GetMountedFilesRaw()
            Dim used As List(Of String) = GetUsedDrives()

            Dim ejectedFiles As New List(Of String)
            For Each kvp As KeyValuePair(Of String, String) In rawMounted
                If Not used.Contains(kvp.Key) Then
                    ejectedFiles.Add(kvp.Value.ToLower())
                    ForgetMounted(kvp.Key)
                End If
            Next

            Dim gp As String = GetGridCachePath()
            If File.Exists(gp) Then
                Dim lines() As String = File.ReadAllLines(gp)
                Dim keep As New List(Of String)
                For Each f As String In lines
                    If Not File.Exists(f) Then Continue For
                    If ejectedFiles.Contains(f.ToLower()) Then Continue For
                    AddFileToList(f)
                    keep.Add(f)
                Next
                Try
                    File.WriteAllLines(gp, keep.ToArray())
                Catch
                End Try
            End If
        Catch
        End Try
        _loadingGrid = False

        cekitem()
        cekdrv()

        ShellIntegration.RefreshShellMenu()

        _autoCheckTimer = New System.Windows.Forms.Timer()
        _autoCheckTimer.Interval = 2000
        _autoCheckTimer.Start()

        ProcessStartupCommand()
    End Sub

    Private Sub ProcessStartupCommand()
        If StartupEjectDrive IsNot Nothing Then
            Dim d As String = StartupEjectDrive.Trim().ToUpper()
            If Not d.EndsWith(":") Then d &= ":"

            Dim used As List(Of String) = GetUsedDrives()
            If Not used.Contains(d) Then
                MessageBox.Show("Drive " & d & " is not currently mounted.", _
                                "Eject", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            Dim mounted As Dictionary(Of String, String) = GetMountedFilesRaw()
            Dim mountedFile As String = ""
            If mounted.ContainsKey(d) Then mountedFile = mounted(d)

            EjectISO(d)

            If mountedFile <> "" Then
                RemoveFileFromList(mountedFile)
                SaveGridList()
                cekitem()
            End If

            RefreshDriveComboBox()
            cekdrv()
            ShellIntegration.RefreshShellMenu()
            Return
        End If

        If StartupFile Is Nothing Then Return

        If FindItemByPath(StartupFile) Is Nothing Then
            AddFileToList(StartupFile)
            SaveGridList()
        End If

        Button5.Enabled = True
        Panel1.Visible = False
        TextBox1.Text = StartupFile

        If StartupMountDrive IsNot Nothing Then
            Dim target As String = StartupMountDrive.ToUpper()
            If Not target.EndsWith(":") Then target &= ":"

            Dim usedNow As List(Of String) = GetUsedDrives()
            If usedNow.Contains(target) Then
                MessageBox.Show("Drive " & target & " is currently in use and cannot be used to mount this image.", _
                                "Drive In Use", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ShowMountDialog(StartupFile)
            Else
                MountISO(target, StartupFile)
                Process.Start(target)
                RefreshDriveComboBox()
                ShellIntegration.RefreshShellMenu()
            End If
            Return
        End If

        If StartupAutoMount Then
            Dim all As List(Of String) = GetAllVirtualDrives()
            If all Is Nothing OrElse all.Count = 0 Then
                MessageBox.Show("No virtual drives found. Please add a virtual drive first.", _
                                "No Virtual Drive", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            Dim freeD As String = GetFreeDrive(all)
            If freeD Is Nothing Then
                MessageBox.Show("All virtual drives are in use.", _
                                "No Free Drive", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ShowMountDialog(StartupFile)
                Return
            End If

            MountISO(freeD, StartupFile)
            Process.Start(freeD)
            RefreshDriveComboBox()
            ShellIntegration.RefreshShellMenu()
            Return
        End If

        ShowMountDialog(StartupFile)
    End Sub

    Private Sub _autoCheckTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles _autoCheckTimer.Tick
        Try
            Dim rawMounted As Dictionary(Of String, String) = GetMountedFilesRaw()
            If rawMounted.Count = 0 Then Return

            Dim used As List(Of String) = GetUsedDrives()
            Dim changed As Boolean = False

            Dim toRemove As New List(Of String)
            For Each kvp As KeyValuePair(Of String, String) In rawMounted
                If Not used.Contains(kvp.Key) Then
                    toRemove.Add(kvp.Key)
                End If
            Next

            If toRemove.Count = 0 Then Return

            For Each drive As String In toRemove
                Dim filePath As String = rawMounted(drive)
                ForgetMounted(drive)

                Dim target As ListViewItem = FindItemByPath(filePath)
                If target IsNot Nothing Then
                    ListView1.Items.Remove(target)
                    changed = True
                End If
            Next

            If changed Then
                SaveGridList()
                cekitem()
                cekdrv()
                RefreshDriveComboBox()
                ShellIntegration.RefreshShellMenu()
            End If
        Catch
        End Try
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            If _autoCheckTimer IsNot Nothing Then
                _autoCheckTimer.Stop()
                _autoCheckTimer.Dispose()
            End If
        Catch
        End Try

        Try
            If _headerFont IsNot Nothing Then
                _headerFont.Dispose()
            End If
        Catch
        End Try

        SaveGridList()
        ShellIntegration.RefreshShellMenu()
        ResourceExtractor.CleanupResources()
    End Sub


    Private Sub ListView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        If ListView1.SelectedItems.Count > 0 Then
            Dim item As ListViewItem = ListView1.SelectedItems(0)
            If item.SubItems.Count >= 3 Then
                TextBox1.Text = item.SubItems(2).Text
            End If
            Button4.Enabled = True
        Else
            Button4.Enabled = False
        End If
        cekdrv()
    End Sub

    Private Sub ListView1_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListView1.MouseDoubleClick
        If ListView1.SelectedItems.Count > 0 Then
            Button2.PerformClick()
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        VirtualDrive.ShowDialog()
        LoadIsoCmdDrives()
        cekdrv()
        ShellIntegration.RefreshShellMenu()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If ListView1.SelectedItems.Count > 0 Then
            Dim sel As New List(Of ListViewItem)
            For Each item As ListViewItem In ListView1.SelectedItems
                sel.Add(item)
            Next
            For Each item As ListViewItem In sel
                ListView1.Items.Remove(item)
            Next
            cekitem()
            cekdrv()
            SaveGridList()
        End If
    End Sub

    Private Function AdaItem() As Boolean
        Return ListView1.Items.Count > 0
    End Function

    Private Sub cekitem()
        If AdaItem() Then
            Panel1.Visible = False
            Button5.Enabled = True
        Else
            Button5.Enabled = False
            Panel1.Visible = True
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        ListView1.Items.Clear()
        _iconList.Images.Clear()
        cekitem()
        cekdrv()
        SaveGridList()
    End Sub

    Private Sub OpenFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFileToolStripMenuItem.Click
        Button1.PerformClick()
    End Sub

    Private Sub MountToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MountToolStripMenuItem.Click
        Button2.PerformClick()
    End Sub

    Private Sub EjectToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EjectToolStripMenuItem.Click
        Button3.PerformClick()
    End Sub

    Private Sub DelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DelToolStripMenuItem.Click
        Button4.PerformClick()
    End Sub

    Private Sub ClearToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripMenuItem.Click
        Button5.PerformClick()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Me.ActiveControl = Nothing
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            Me.TopMost = True
        Else
            Me.TopMost = False
        End If
    End Sub

    Private Sub CheckBox1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox1.MouseEnter
        CheckBox1.ForeColor = Color.Firebrick
    End Sub

    Private Sub CheckBox1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox1.MouseLeave
        CheckBox1.ForeColor = Color.Black
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.ActiveControl = Nothing
        Dim dlg As New OpenFileDialog()
        dlg.Multiselect = True

        dlg.Filter = "Disc Image Files|*.iso;*.bin;*.img;*.cif;*.nrg;*.mds;*.ccd;*.bwi;*.isz;*.dmg;*.daa;*.uif;*.hfs"

        If dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then

            Dim allowedExt() As String = {".iso", ".bin", ".img", ".cif", ".nrg", _
                                          ".mds", ".ccd", ".bwi", ".isz", ".dmg", _
                                          ".daa", ".uif", ".hfs"}

            For Each f As String In dlg.FileNames

                Dim ext As String = LCase(System.IO.Path.GetExtension(f))

                If Array.IndexOf(allowedExt, ext) = -1 Then
                    MessageBox.Show("Format tidak didukung: " & f)
                    Continue For
                End If

                If FindItemByPath(f) IsNot Nothing Then
                    MessageBox.Show("The file already exists in the list: " & f)
                    Continue For
                End If

                AddFileToList(f)
                cekitem()
                cekdrv()
            Next

            SaveGridList()
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Me.ActiveControl = Nothing
        Try
            Process.Start("https://udiscmounter.github.io/content/")
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Me.ActiveControl = Nothing
        frmAbout.ShowDialog()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.ActiveControl = Nothing

        Dim drive As String = GetSelectedDriveLetter()
        Dim iso As String = TextBox1.Text

        If iso = "" OrElse Not File.Exists(iso) Then
            MessageBox.Show("Please select a disc image file first.", "No File Selected", _
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim usedDrives As List(Of String) = GetUsedDrives()
        If usedDrives.Contains(drive.ToUpper()) Then
            Dim freeDrive As String = GetFreeDrive(_allDriveList)
            If freeDrive IsNot Nothing Then
                Dim msg As String = "Drive " & drive & " is currently in use." & vbCrLf & _
                                    "Switch to free drive " & freeDrive & " instead?"
                Dim res As DialogResult = MessageBox.Show(msg, "Drive In Use", _
                                                          MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If res = DialogResult.Yes Then
                    drive = freeDrive
                    For idx As Integer = 0 To ComboBox1.Items.Count - 1
                        If ComboBox1.Items(idx).ToString().StartsWith(freeDrive) Then
                            ComboBox1.SelectedIndex = idx
                            Exit For
                        End If
                    Next
                End If
            Else
                Dim res As DialogResult = MessageBox.Show("Drive " & drive & " is in use and all other drives are busy." & vbCrLf & _
                                                           "Mount anyway (will replace current)?", _
                                                           "All Drives Busy", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
                If res = DialogResult.No Then Return
            End If
        End If

        MountISO(drive, iso)
        Process.Start(drive)

        RefreshDriveComboBox()
        cekdrv()
        SaveGridList()
        ShellIntegration.RefreshShellMenu()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.ActiveControl = Nothing
        Dim drive As String = GetSelectedDriveLetter()

        Dim mounted As Dictionary(Of String, String) = GetMountedFilesRaw()
        Dim mountedFile As String = ""
        If mounted.ContainsKey(drive.ToUpper()) Then
            mountedFile = mounted(drive.ToUpper())
        End If

        EjectISO(drive)

        If mountedFile <> "" Then
            RemoveFileFromList(mountedFile)
            SaveGridList()
            cekitem()
        End If

        RefreshDriveComboBox()
        cekdrv()
        ShellIntegration.RefreshShellMenu()
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        Me.ActiveControl = Nothing
        Dim dlg As New OpenFileDialog()
        dlg.Multiselect = True

        dlg.Filter = "Disc Image Files|*.iso;*.bin;*.img;*.cif;*.nrg;*.mds;*.ccd;*.bwi;*.isz;*.dmg;*.daa;*.uif;*.hfs"

        If dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then

            Dim allowedExt() As String = {".iso", ".bin", ".img", ".cif", ".nrg", _
                                          ".mds", ".ccd", ".bwi", ".isz", ".dmg", _
                                          ".daa", ".uif", ".hfs"}

            For Each f As String In dlg.FileNames

                Dim ext As String = LCase(System.IO.Path.GetExtension(f))

                If Array.IndexOf(allowedExt, ext) = -1 Then
                    MessageBox.Show("Format tidak didukung: " & f)
                    Continue For
                End If

                If FindItemByPath(f) IsNot Nothing Then
                    MessageBox.Show("The file already exists in the list: " & f)
                    Continue For
                End If

                AddFileToList(f)
                cekitem()
                cekdrv()
            Next

            SaveGridList()
        End If
    End Sub

    Private Sub DelToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DelToolStripMenuItem1.Click
        If ListView1.SelectedItems.Count > 0 Then
            Dim sel As New List(Of ListViewItem)
            For Each item As ListViewItem In ListView1.SelectedItems
                sel.Add(item)
            Next
            For Each item As ListViewItem In sel
                ListView1.Items.Remove(item)
            Next
            cekitem()
            cekdrv()
            SaveGridList()
        End If
    End Sub

    Private Sub ClearToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripMenuItem1.Click
        ListView1.Items.Clear()
        _iconList.Images.Clear()
        cekitem()
        cekdrv()
        SaveGridList()
    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click

    End Sub

    Private Sub Label6_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label6.MouseEnter
        Label6.ForeColor = Color.LightBlue
    End Sub

    Private Sub Label6_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label6.MouseLeave
        Label6.ForeColor = SystemColors.ControlDark
    End Sub
End Class