﻿Imports System.IO
Imports System.Reflection
Imports System.Security.Cryptography
Imports System.Text

Module ResourceExtractor
    Private _tempDir As String

    Private ReadOnly Property CryptoPassword() As String
        Get
            Dim p1 As String = "uDM_K3y_"
            Dim p2 As String = "2024_@#!"
            Dim p3 As String = "x9"
            Return p1 & p2 & p3
        End Get
    End Property

    Private ReadOnly Property DecryptionKey() As Byte()
        Get
            Dim sha As SHA256 = SHA256.Create()
            Return sha.ComputeHash(Encoding.UTF8.GetBytes(CryptoPassword))
        End Get
    End Property

    Private ReadOnly Property DecryptionIV() As Byte()
        Get
            Dim md5 As MD5 = MD5.Create()
            Return md5.ComputeHash(Encoding.UTF8.GetBytes(CryptoPassword & "_IVSALT_"))
        End Get
    End Property

    Public ReadOnly Property TempDir() As String
        Get
            If _tempDir Is Nothing Then
                _tempDir = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "uDiscMounter")
            End If
            Return _tempDir
        End Get
    End Property

    Public ReadOnly Property IsoCmdPath() As String
        Get
            Return System.IO.Path.Combine(TempDir, "IsoCmd.exe")
        End Get
    End Property

    Public ReadOnly Property IsoDrive32Path() As String
        Get
            Return System.IO.Path.Combine(TempDir, "ISODrive.sys")
        End Get
    End Property

    Public ReadOnly Property IsoDrive64Path() As String
        Get
            Return System.IO.Path.Combine(TempDir, "ISODrv64.sys")
        End Get
    End Property

    Public Function IsReady() As Boolean
        Try
            Return File.Exists(IsoCmdPath)
        Catch
            Return False
        End Try
    End Function

    Public Function ListEmbeddedResources() As String
        Try
            Dim asm As Assembly = Assembly.GetExecutingAssembly()
            Dim names() As String = asm.GetManifestResourceNames()
            Return String.Join(vbCrLf, names)
        Catch ex As Exception
            Return "Error: " & ex.Message
        End Try
    End Function

    Public Sub ExtractResources()
        Try
            If Not Directory.Exists(TempDir) Then
                Directory.CreateDirectory(TempDir)
            End If

            Dim asm As Assembly = Assembly.GetExecutingAssembly()
            Dim names() As String = asm.GetManifestResourceNames()

            Dim srcIsoCmd As String = FindResourceEndingWith(names, "udisctool.dll")
            Dim srcIsoDrive As String = FindResourceEndingWith(names, "udisclib.dll")
            Dim srcIsoDrv64 As String = FindResourceEndingWith(names, "udisclib64.dll")

            If srcIsoCmd IsNot Nothing Then
                ExtractFromAssembly(asm, srcIsoCmd, IsoCmdPath)
            End If

            If srcIsoDrive IsNot Nothing Then
                ExtractFromAssembly(asm, srcIsoDrive, IsoDrive32Path)
            End If

            If srcIsoDrv64 IsNot Nothing Then
                ExtractFromAssembly(asm, srcIsoDrv64, IsoDrive64Path)
            End If

        Catch ex As Exception
        End Try
    End Sub

    Private Function FindResourceEndingWith(ByVal allNames() As String, ByVal fileName As String) As String
        Dim target As String = fileName.ToLower()
        For Each n As String In allNames
            If n.ToLower().EndsWith(target) Then
                Return n
            End If
        Next
        Return Nothing
    End Function

    Private Function DecryptBytes(ByVal encrypted As Byte()) As Byte()
        Dim aes As New RijndaelManaged()
        Try
            aes.KeySize = 256
            aes.BlockSize = 128
            aes.Mode = CipherMode.CBC
            aes.Padding = PaddingMode.PKCS7
            aes.Key = DecryptionKey
            aes.IV = DecryptionIV

            Dim decryptor As ICryptoTransform = aes.CreateDecryptor()
            Return decryptor.TransformFinalBlock(encrypted, 0, encrypted.Length)
        Finally
            aes.Clear()
        End Try
    End Function

    Private Sub ExtractFromAssembly(ByVal asm As Assembly, ByVal resourceName As String, ByVal outPath As String)
        Try
            If File.Exists(outPath) Then
                Try
                    File.SetAttributes(outPath, FileAttributes.Normal)
                    File.Delete(outPath)
                Catch
                End Try
            End If

            Dim encryptedBytes As Byte() = Nothing

            Using s As Stream = asm.GetManifestResourceStream(resourceName)
                If s Is Nothing Then Return

                Using ms As New MemoryStream()
                    Dim buf(8191) As Byte
                    Dim n As Integer
                    Do
                        n = s.Read(buf, 0, buf.Length)
                        If n > 0 Then ms.Write(buf, 0, n)
                    Loop While n > 0
                    encryptedBytes = ms.ToArray()
                End Using
            End Using

            If encryptedBytes Is Nothing OrElse encryptedBytes.Length = 0 Then Return

            Dim decrypted As Byte() = DecryptBytes(encryptedBytes)

            If decrypted.Length < 2 Then Return

            If outPath.ToLower().EndsWith(".exe") Then
                If decrypted(0) <> &H4D OrElse decrypted(1) <> &H5A Then
                    Return
                End If
            End If

            File.WriteAllBytes(outPath, decrypted)

        Catch
        End Try
    End Sub

    Public Sub CleanupResources()
        Try
            If Directory.Exists(TempDir) Then
                For Each f As String In Directory.GetFiles(TempDir)
                    Try
                        File.SetAttributes(f, FileAttributes.Normal)
                    Catch
                    End Try
                Next
                Directory.Delete(TempDir, True)
            End If
        Catch
        End Try
    End Sub
End Module