Imports System.Diagnostics
Imports System.IO

Module Operations

    Private _sessionMounted As New Dictionary(Of String, String)
    Private _cacheFile As String

    Private Function GetCacheFile() As String
        If _cacheFile Is Nothing Then
            Dim dir As String = System.IO.Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "uDiscMounter")
            If Not Directory.Exists(dir) Then
                Try
                    Directory.CreateDirectory(dir)
                Catch
                End Try
            End If
            _cacheFile = System.IO.Path.Combine(dir, "mounted.dat")
        End If
        Return _cacheFile
    End Function

    Private Sub LoadCache()
        If _sessionMounted.Count > 0 Then Return
        Try
            Dim cf As String = GetCacheFile()
            If Not File.Exists(cf) Then Return

            Dim lines() As String = File.ReadAllLines(cf)
            For Each line As String In lines
                Dim idx As Integer = line.IndexOf("|")
                If idx > 0 Then
                    Dim d As String = line.Substring(0, idx).Trim().ToUpper()
                    Dim p As String = line.Substring(idx + 1).Trim()
                    If d.EndsWith(":") AndAlso p <> "" Then
                        _sessionMounted(d) = p
                    End If
                End If
            Next
        Catch
        End Try
    End Sub

    Private Sub SaveCache()
        Try
            Dim out As New List(Of String)
            For Each kvp As KeyValuePair(Of String, String) In _sessionMounted
                out.Add(kvp.Key & "|" & kvp.Value)
            Next
            File.WriteAllLines(GetCacheFile(), out.ToArray())
        Catch
        End Try
    End Sub

    Public Sub RememberMounted(ByVal driveLetter As String, ByVal isoPath As String)
        LoadCache()
        Dim d As String = driveLetter.ToUpper().Trim()
        If Not d.EndsWith(":") Then d &= ":"
        _sessionMounted(d) = isoPath
        SaveCache()
    End Sub

    Public Sub ForgetMounted(ByVal driveLetter As String)
        LoadCache()
        Dim d As String = driveLetter.ToUpper().Trim()
        If Not d.EndsWith(":") Then d &= ":"
        _sessionMounted.Remove(d)
        SaveCache()
    End Sub

    Public Function GetMountedFilesRaw() As Dictionary(Of String, String)
        LoadCache()
        Return New Dictionary(Of String, String)(_sessionMounted)
    End Function

    Public Function GetMountedFiles() As Dictionary(Of String, String)
        LoadCache()

        Dim valid As New Dictionary(Of String, String)
        Dim used As List(Of String) = GetUsedDrives()

        For Each kvp As KeyValuePair(Of String, String) In _sessionMounted
            If used.Contains(kvp.Key) Then
                valid(kvp.Key) = kvp.Value
            End If
        Next

        If valid.Count <> _sessionMounted.Count Then
            _sessionMounted = New Dictionary(Of String, String)(valid)
            SaveCache()
        End If

        Return valid
    End Function

    Public Function GetAllVirtualDrives() As List(Of String)
        Dim result As New List(Of String)
        Try
            Dim p As New Process()
            p.StartInfo.FileName = ResourceExtractor.IsoCmdPath
            p.StartInfo.WorkingDirectory = ResourceExtractor.TempDir
            p.StartInfo.Arguments = "-print"
            p.StartInfo.UseShellExecute = False
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.RedirectStandardError = True
            p.StartInfo.CreateNoWindow = True

            p.Start()
            Dim output As String = p.StandardOutput.ReadToEnd()
            p.StandardError.ReadToEnd()
            p.WaitForExit()

            For Each line As String In output.Split(ControlChars.Lf)
                Dim l As String = line.Trim()
                If l.Contains("DriveLetters=[") Then
                    Dim s As Integer = l.IndexOf("["c) + 1
                    Dim f As Integer = l.IndexOf("]"c)
                    If s > 0 AndAlso f > s Then
                        Dim inside As String = l.Substring(s, f - s).Trim()
                        Dim drives() As String
                        If inside.IndexOf(","c) >= 0 Then
                            drives = inside.Split(","c)
                        Else
                            If inside.Length > 0 Then
                                ReDim drives(inside.Length - 1)
                                For i As Integer = 0 To inside.Length - 1
                                    drives(i) = inside.Substring(i, 1)
                                Next
                            Else
                                ReDim drives(-1)
                            End If
                        End If
                        For Each d As String In drives
                            If d IsNot Nothing Then
                                d = d.Trim()
                                If d <> "" Then result.Add(d.ToUpper() & ":")
                            End If
                        Next
                    End If
                End If
            Next
        Catch
        End Try
        Return result
    End Function

    Public Function MountISO(ByVal driveLetter As String, ByVal isoPath As String) As String
        Try
            If driveLetter.EndsWith(":") = False Then
                driveLetter &= ":"
            End If

            Dim args As String = "-mount " & driveLetter & " """ & isoPath & """"

            Dim p As New Process()
            p.StartInfo.FileName = ResourceExtractor.IsoCmdPath
            p.StartInfo.WorkingDirectory = ResourceExtractor.TempDir
            p.StartInfo.Arguments = args
            p.StartInfo.UseShellExecute = False
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.RedirectStandardError = True
            p.StartInfo.CreateNoWindow = True

            p.Start()

            p.StandardOutput.ReadToEnd()
            p.StandardError.ReadToEnd()

            p.WaitForExit()

            RememberMounted(driveLetter, isoPath)
            Return ""

        Catch ex As Exception
            Return "Unable to mount the image. " & ex.Message
        End Try
    End Function

    Public Function EjectISO(ByVal driveLetter As String) As String
        Try
            If driveLetter.EndsWith(":") = False Then
                driveLetter &= ":"
            End If

            Dim args As String = "-eject " & driveLetter

            Dim p As New Process()
            p.StartInfo.FileName = ResourceExtractor.IsoCmdPath
            p.StartInfo.WorkingDirectory = ResourceExtractor.TempDir
            p.StartInfo.Arguments = args
            p.StartInfo.UseShellExecute = False
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.RedirectStandardError = True
            p.StartInfo.CreateNoWindow = True

            p.Start()

            p.StandardOutput.ReadToEnd()
            p.StandardError.ReadToEnd()

            p.WaitForExit()

            ForgetMounted(driveLetter)
            Return ""

        Catch ex As Exception
            Return "Unable to eject the drive. " & ex.Message
        End Try
    End Function

    Public Function SetDriveCount(ByVal count As Integer) As String
        Try
            Dim args As String = "-number " & count.ToString()

            Dim p As New Process()
            p.StartInfo.FileName = ResourceExtractor.IsoCmdPath
            p.StartInfo.WorkingDirectory = ResourceExtractor.TempDir
            p.StartInfo.Arguments = args
            p.StartInfo.UseShellExecute = True
            p.StartInfo.Verb = "runas"
            p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden

            p.Start()
            p.WaitForExit()

            Return ""

        Catch ex As Exception
            Return "Unable to configure virtual drives. " & ex.Message
        End Try
    End Function

    Public Function GetUsedDrives() As List(Of String)
        Dim usedDrives As New List(Of String)
        Try
            For Each di As IO.DriveInfo In IO.DriveInfo.GetDrives()
                If di.DriveType = IO.DriveType.CDRom Then
                    Try
                        If di.IsReady Then
                            Dim dl As String = di.Name.Substring(0, 2).ToUpper()
                            If Not usedDrives.Contains(dl) Then
                                usedDrives.Add(dl)
                            End If
                        End If
                    Catch
                    End Try
                End If
            Next
        Catch
        End Try
        Return usedDrives
    End Function

    Public Function GetFreeDrive(ByVal allDrives As List(Of String)) As String
        Dim used As List(Of String) = GetUsedDrives()
        For Each drv As String In allDrives
            If Not used.Contains(drv.ToUpper()) Then
                Return drv
            End If
        Next
        Return Nothing
    End Function

End Module