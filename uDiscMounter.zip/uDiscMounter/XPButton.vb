﻿Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Windows.Forms

Public Class XPButton
    Inherits Control

    Private _hover As Boolean = False
    Private _pressed As Boolean = False
    Private _text As String = ""
    Private _img As Image = Nothing
    Private _dialogResult As DialogResult = DialogResult.None

    Public Sub New()
        SetStyle(ControlStyles.UserPaint Or _
                 ControlStyles.AllPaintingInWmPaint Or _
                 ControlStyles.DoubleBuffer Or _
                 ControlStyles.ResizeRedraw Or _
                 ControlStyles.SupportsTransparentBackColor Or _
                 ControlStyles.Selectable Or _
                 ControlStyles.StandardClick Or _
                 ControlStyles.StandardDoubleClick, True)

        Me.BackColor = Color.White
        Me.Font = New Font("Tahoma", 8, FontStyle.Regular)
        Me.Cursor = Cursors.Hand
        Me.TabStop = True
        Me.DoubleBuffered = True
    End Sub

    <DefaultValue("")> _
    Public Overrides Property Text() As String
        Get
            Return _text
        End Get
        Set(ByVal value As String)
            _text = value
            Invalidate()
        End Set
    End Property

    <DefaultValue(GetType(Image), Nothing)> _
    Public Property Image() As Image
        Get
            Return _img
        End Get
        Set(ByVal value As Image)
            _img = value
            Invalidate()
        End Set
    End Property

    <DefaultValue(DialogResult.None)> _
    Public Property DialogResult() As DialogResult
        Get
            Return _dialogResult
        End Get
        Set(ByVal value As DialogResult)
            _dialogResult = value
        End Set
    End Property

    <DefaultValue(ContentAlignment.MiddleCenter)> _
    Public Property ImageAlign() As ContentAlignment
        Get
            Return _imgAlign
        End Get
        Set(ByVal value As ContentAlignment)
            _imgAlign = value
            Invalidate()
        End Set
    End Property
    Private _imgAlign As ContentAlignment = ContentAlignment.MiddleCenter

    <DefaultValue(ContentAlignment.MiddleCenter)> _
    Public Property TextAlign() As ContentAlignment
        Get
            Return _textAlign
        End Get
        Set(ByVal value As ContentAlignment)
            _textAlign = value
            Invalidate()
        End Set
    End Property
    Private _textAlign As ContentAlignment = ContentAlignment.MiddleCenter

    <DefaultValue(True)> _
    Public Property UseVisualStyleBackColor() As Boolean
        Get
            Return _useVisualStyle
        End Get
        Set(ByVal value As Boolean)
            _useVisualStyle = value
        End Set
    End Property
    Private _useVisualStyle As Boolean = True

    <DefaultValue(FlatStyle.Flat)> _
    Public Property FlatStyle() As FlatStyle
        Get
            Return _flatStyle
        End Get
        Set(ByVal value As FlatStyle)
            _flatStyle = value
            Invalidate()
        End Set
    End Property
    Private _flatStyle As FlatStyle = FlatStyle.Flat

    Public Sub PerformClick()
        Me.OnClick(EventArgs.Empty)
    End Sub

    Protected Overrides Sub OnPaint(ByVal pevent As PaintEventArgs)
        Dim g As Graphics = pevent.Graphics
        g.SmoothingMode = SmoothingMode.AntiAlias
        g.TextRenderingHint = Drawing.Text.TextRenderingHint.ClearTypeGridFit

        Using br As New SolidBrush(Me.BackColor)
            g.FillRectangle(br, Me.ClientRectangle)
        End Using

        If Me.Width <= 2 OrElse Me.Height <= 2 Then Return

        Dim cTop As Color
        Dim cBottom As Color

        If Not Me.Enabled Then
            cTop = Color.White
            cBottom = Color.FromArgb(248, 248, 248)
        ElseIf _pressed Then
            cTop = Color.FromArgb(205, 222, 245)
            cBottom = Color.FromArgb(232, 240, 252)
        ElseIf _hover Then
            cTop = Color.FromArgb(242, 248, 255)
            cBottom = Color.FromArgb(213, 231, 252)
        Else
            cTop = Color.White
            cBottom = Color.White
        End If

        Dim fillRect As New Rectangle(1, 1, Me.Width - 2, Me.Height - 2)
        If fillRect.Width > 0 AndAlso fillRect.Height > 0 Then
            If cTop = cBottom Then
                Using b As New SolidBrush(cTop)
                    g.FillRectangle(b, fillRect)
                End Using
            Else
                Using lg As New LinearGradientBrush(fillRect, cTop, cBottom, LinearGradientMode.Vertical)
                    g.FillRectangle(lg, fillRect)
                End Using
            End If
        End If

        If _hover AndAlso Me.Enabled AndAlso Me.Width > 12 Then
            Using p As New Pen(Color.FromArgb(120, 160, 220), 1)
                g.DrawLine(p, 5, Me.Height - 2, Me.Width - 6, Me.Height - 2)
            End Using
        End If

        If Me.Focused AndAlso Me.ShowFocusCues AndAlso Me.Width > 8 AndAlso Me.Height > 8 Then
            Dim fr As New Rectangle(3, 3, Me.Width - 7, Me.Height - 7)
            ControlPaint.DrawFocusRectangle(g, fr, Color.FromArgb(80, 120, 180), Color.Transparent)
        End If

        Dim textColor As Color
        If Not Me.Enabled Then
            textColor = Color.FromArgb(180, 180, 180)
        ElseIf _hover OrElse _pressed Then
            textColor = Color.FromArgb(0, 60, 130)
        Else
            textColor = Color.FromArgb(60, 60, 65)
        End If

        Dim textRect As New Rectangle(0, 0, Me.Width, Me.Height)
        If _pressed Then textRect.Offset(1, 1)

        Dim flags As TextFormatFlags = TextFormatFlags.HorizontalCenter Or _
                                       TextFormatFlags.VerticalCenter Or _
                                       TextFormatFlags.NoPrefix Or _
                                       TextFormatFlags.WordEllipsis

        If _img IsNot Nothing Then
            Dim imgX As Integer = (Me.Width - _img.Width) \ 2
            Dim imgY As Integer = (Me.Height - _img.Height) \ 2 - 4
            If _pressed Then
                imgX += 1
                imgY += 1
            End If
            g.DrawImage(_img, imgX, imgY, _img.Width, _img.Height)

            Dim textBelow As New Rectangle(0, imgY + _img.Height, Me.Width, Me.Height - (imgY + _img.Height))
            If _pressed Then textBelow.Offset(1, 1)

            TextRenderer.DrawText(g, _text, Me.Font, textBelow, textColor, flags)
        Else
            TextRenderer.DrawText(g, _text, Me.Font, textRect, textColor, flags)
        End If
    End Sub

    Protected Overrides Sub OnMouseEnter(ByVal e As EventArgs)
        _hover = True
        Invalidate()
        MyBase.OnMouseEnter(e)
    End Sub

    Protected Overrides Sub OnMouseLeave(ByVal e As EventArgs)
        _hover = False
        _pressed = False
        Invalidate()
        MyBase.OnMouseLeave(e)
    End Sub

    Protected Overrides Sub OnMouseDown(ByVal mevent As MouseEventArgs)
        If mevent.Button = MouseButtons.Left Then
            _pressed = True
            Me.Focus()
            Invalidate()
        End If
        MyBase.OnMouseDown(mevent)
    End Sub

    Protected Overrides Sub OnMouseUp(ByVal mevent As MouseEventArgs)
        If _pressed Then
            _pressed = False
            Invalidate()
            If Me.ClientRectangle.Contains(mevent.Location) Then
                Me.OnClick(EventArgs.Empty)
                If _dialogResult <> DialogResult.None Then
                    Dim f As Form = Me.FindForm()
                    If f IsNot Nothing Then
                        f.DialogResult = _dialogResult
                    End If
                End If
            End If
        End If
        MyBase.OnMouseUp(mevent)
    End Sub

    Protected Overrides Sub OnGotFocus(ByVal e As EventArgs)
        Invalidate()
        MyBase.OnGotFocus(e)
    End Sub

    Protected Overrides Sub OnLostFocus(ByVal e As EventArgs)
        _pressed = False
        Invalidate()
        MyBase.OnLostFocus(e)
    End Sub

    Protected Overrides Sub OnKeyDown(ByVal kevent As KeyEventArgs)
        If kevent.KeyCode = Keys.Space OrElse kevent.KeyCode = Keys.Enter Then
            If Not _pressed Then
                _pressed = True
                Invalidate()
            End If
        End If
        MyBase.OnKeyDown(kevent)
    End Sub

    Protected Overrides Sub OnKeyUp(ByVal kevent As KeyEventArgs)
        If _pressed Then
            _pressed = False
            Invalidate()
            If kevent.KeyCode = Keys.Space OrElse kevent.KeyCode = Keys.Enter Then
                Me.OnClick(EventArgs.Empty)
                If _dialogResult <> DialogResult.None Then
                    Dim f As Form = Me.FindForm()
                    If f IsNot Nothing Then
                        f.DialogResult = _dialogResult
                    End If
                End If
            End If
        End If
        MyBase.OnKeyUp(kevent)
    End Sub

    Protected Overrides Sub OnTextChanged(ByVal e As EventArgs)
        Invalidate()
        MyBase.OnTextChanged(e)
    End Sub

    Protected Overrides Sub OnEnabledChanged(ByVal e As EventArgs)
        Invalidate()
        MyBase.OnEnabledChanged(e)
    End Sub
End Class