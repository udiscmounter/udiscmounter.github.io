﻿Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Windows.Forms

Public Class XPButtonLuna
    Inherits Control

    Private _hover As Boolean = False
    Private _pressed As Boolean = False
    Private _text As String = ""
    Private _img As Image = Nothing
    Private _dialogResult As DialogResult = DialogResult.None
    Private _baseColor As Color = Color.FromArgb(60, 120, 180)

    Public Sub New()
        SetStyle(ControlStyles.UserPaint Or _
                 ControlStyles.AllPaintingInWmPaint Or _
                 ControlStyles.DoubleBuffer Or _
                 ControlStyles.ResizeRedraw Or _
                 ControlStyles.SupportsTransparentBackColor Or _
                 ControlStyles.Selectable Or _
                 ControlStyles.StandardClick Or _
                 ControlStyles.StandardDoubleClick, True)

        Me.BackColor = Color.White
        Me.Font = New Font("Tahoma", 8, FontStyle.Regular)
        Me.Cursor = Cursors.Hand
        Me.TabStop = True
        Me.DoubleBuffered = True
        Me.Height = 26
    End Sub

    <DefaultValue(GetType(Color), "60, 120, 180")> _
    Public Property BaseColor() As Color
        Get
            Return _baseColor
        End Get
        Set(ByVal value As Color)
            _baseColor = value
            Invalidate()
        End Set
    End Property

    <DefaultValue("")> _
    Public Overrides Property Text() As String
        Get
            Return _text
        End Get
        Set(ByVal value As String)
            _text = value
            Invalidate()
        End Set
    End Property

    <DefaultValue(GetType(Image), Nothing)> _
    Public Property Image() As Image
        Get
            Return _img
        End Get
        Set(ByVal value As Image)
            _img = value
            Invalidate()
        End Set
    End Property

    <DefaultValue(DialogResult.None)> _
    Public Property DialogResult() As DialogResult
        Get
            Return _dialogResult
        End Get
        Set(ByVal value As DialogResult)
            _dialogResult = value
        End Set
    End Property

    <DefaultValue(ContentAlignment.MiddleCenter)> _
    Public Property ImageAlign() As ContentAlignment
        Get
            Return _imgAlign
        End Get
        Set(ByVal value As ContentAlignment)
            _imgAlign = value
            Invalidate()
        End Set
    End Property
    Private _imgAlign As ContentAlignment = ContentAlignment.MiddleCenter

    <DefaultValue(ContentAlignment.MiddleCenter)> _
    Public Property TextAlign() As ContentAlignment
        Get
            Return _textAlign
        End Get
        Set(ByVal value As ContentAlignment)
            _textAlign = value
            Invalidate()
        End Set
    End Property
    Private _textAlign As ContentAlignment = ContentAlignment.MiddleCenter

    <DefaultValue(True)> _
    Public Property UseVisualStyleBackColor() As Boolean
        Get
            Return _useVisualStyle
        End Get
        Set(ByVal value As Boolean)
            _useVisualStyle = value
        End Set
    End Property
    Private _useVisualStyle As Boolean = True

    <DefaultValue(FlatStyle.Flat)> _
    Public Property FlatStyle() As FlatStyle
        Get
            Return _flatStyle
        End Get
        Set(ByVal value As FlatStyle)
            _flatStyle = value
            Invalidate()
        End Set
    End Property
    Private _flatStyle As FlatStyle = FlatStyle.Flat

    Public Sub PerformClick()
        Me.OnClick(EventArgs.Empty)
    End Sub

    Private Function Blend(ByVal c As Color, ByVal target As Color, ByVal amount As Double) As Color
        Dim r As Integer = CInt(c.R * (1 - amount) + target.R * amount)
        Dim g As Integer = CInt(c.G * (1 - amount) + target.G * amount)
        Dim b As Integer = CInt(c.B * (1 - amount) + target.B * amount)
        If r < 0 Then r = 0
        If r > 255 Then r = 255
        If g < 0 Then g = 0
        If g > 255 Then g = 255
        If b < 0 Then b = 0
        If b > 255 Then b = 255
        Return Color.FromArgb(r, g, b)
    End Function

    Private Function IsMiddleV(ByVal align As ContentAlignment) As Boolean
        Return align = ContentAlignment.MiddleLeft OrElse _
               align = ContentAlignment.MiddleCenter OrElse _
               align = ContentAlignment.MiddleRight
    End Function

    Private Function AlignToFlags(ByVal align As ContentAlignment) As TextFormatFlags
        Dim f As TextFormatFlags = TextFormatFlags.NoPrefix Or TextFormatFlags.WordEllipsis

        If align = ContentAlignment.TopLeft OrElse _
           align = ContentAlignment.MiddleLeft OrElse _
           align = ContentAlignment.BottomLeft Then
            f = f Or TextFormatFlags.Left
        ElseIf align = ContentAlignment.TopRight OrElse _
               align = ContentAlignment.MiddleRight OrElse _
               align = ContentAlignment.BottomRight Then
            f = f Or TextFormatFlags.Right
        Else
            f = f Or TextFormatFlags.HorizontalCenter
        End If

        If align = ContentAlignment.TopLeft OrElse _
           align = ContentAlignment.TopCenter OrElse _
           align = ContentAlignment.TopRight Then
            f = f Or TextFormatFlags.Top
        ElseIf align = ContentAlignment.BottomLeft OrElse _
               align = ContentAlignment.BottomCenter OrElse _
               align = ContentAlignment.BottomRight Then
            f = f Or TextFormatFlags.Bottom
        Else
            f = f Or TextFormatFlags.VerticalCenter
        End If

        Return f
    End Function

    Private Function GetAlignedRect(ByVal container As Rectangle, ByVal w As Integer, ByVal h As Integer, ByVal align As ContentAlignment) As Rectangle
        Dim x As Integer = container.Left
        Dim y As Integer = container.Top

        If align = ContentAlignment.TopLeft OrElse _
           align = ContentAlignment.MiddleLeft OrElse _
           align = ContentAlignment.BottomLeft Then
            x = container.Left + 6
        ElseIf align = ContentAlignment.TopRight OrElse _
               align = ContentAlignment.MiddleRight OrElse _
               align = ContentAlignment.BottomRight Then
            x = container.Right - w - 6
        Else
            x = container.Left + (container.Width - w) \ 2
        End If

        If align = ContentAlignment.TopLeft OrElse _
           align = ContentAlignment.TopCenter OrElse _
           align = ContentAlignment.TopRight Then
            y = container.Top + 4
        ElseIf align = ContentAlignment.BottomLeft OrElse _
               align = ContentAlignment.BottomCenter OrElse _
               align = ContentAlignment.BottomRight Then
            y = container.Bottom - h - 4
        Else
            y = container.Top + (container.Height - h) \ 2
        End If

        Return New Rectangle(x, y, w, h)
    End Function

    Protected Overrides Sub OnPaint(ByVal pevent As PaintEventArgs)
        Dim g As Graphics = pevent.Graphics
        g.SmoothingMode = SmoothingMode.AntiAlias
        g.TextRenderingHint = Drawing.Text.TextRenderingHint.ClearTypeGridFit

        Using br As New SolidBrush(Me.BackColor)
            g.FillRectangle(br, Me.ClientRectangle)
        End Using

        If Me.Width <= 2 OrElse Me.Height <= 2 Then Return

        Dim rect As New Rectangle(0, 0, Me.Width - 1, Me.Height - 1)

        Dim cTop As Color
        Dim cBottom As Color
        Dim cBorder As Color
        Dim cText As Color

        Dim white As Color = Color.White

        If Not Me.Enabled Then
            cTop = Color.FromArgb(252, 252, 252)
            cBottom = Color.FromArgb(248, 248, 248)
            cBorder = Color.FromArgb(225, 225, 225)
            cText = Color.FromArgb(190, 190, 190)
        ElseIf _pressed Then
            cTop = _baseColor
            cBottom = _baseColor
            cBorder = _baseColor
            cText = Color.White
        ElseIf _hover Then
            cTop = Blend(_baseColor, white, 0.92)
            cBottom = Blend(_baseColor, white, 0.82)
            cBorder = Blend(_baseColor, white, 0.35)
            cText = Blend(_baseColor, Color.Black, 0.15)
        Else
            cTop = Color.White
            cBottom = Color.White
            cBorder = Color.FromArgb(215, 220, 228)
            cText = Color.FromArgb(70, 75, 85)
        End If

        Using p As New Pen(cBorder)
            g.DrawRectangle(p, rect)
        End Using

        Dim fillRect As New Rectangle(rect.X + 1, rect.Y + 1, rect.Width - 2, rect.Height - 2)
        If fillRect.Width > 0 AndAlso fillRect.Height > 0 Then
            If cTop = cBottom Then
                Using b As New SolidBrush(cTop)
                    g.FillRectangle(b, fillRect)
                End Using
            Else
                Using lg As New LinearGradientBrush(fillRect, cTop, cBottom, LinearGradientMode.Vertical)
                    g.FillRectangle(lg, fillRect)
                End Using
            End If
        End If

        If Me.Focused AndAlso Me.ShowFocusCues AndAlso Me.Width > 10 AndAlso Me.Height > 10 Then
            Dim fr As New Rectangle(3, 3, Me.Width - 7, Me.Height - 7)
            ControlPaint.DrawFocusRectangle(g, fr, cText, Color.Transparent)
        End If

        Dim flags As TextFormatFlags = AlignToFlags(_textAlign)

        If _img IsNot Nothing Then
            Dim imgMiddleV As Boolean = IsMiddleV(_imgAlign)
            Dim txtMiddleV As Boolean = IsMiddleV(_textAlign)

            If imgMiddleV AndAlso txtMiddleV Then
                Dim gap As Integer = 6
                Dim textSize As Size = TextRenderer.MeasureText(_text, Me.Font)
                Dim totalW As Integer = _img.Width + gap + textSize.Width

                Dim startX As Integer
                If _textAlign = ContentAlignment.MiddleLeft Then
                    startX = 6
                ElseIf _textAlign = ContentAlignment.MiddleRight Then
                    startX = Me.Width - totalW - 6
                Else
                    startX = (Me.Width - totalW) \ 2
                End If

                Dim imgY As Integer = (Me.Height - _img.Height) \ 2
                Dim drawImgX As Integer = startX
                Dim drawImgY As Integer = imgY
                If _pressed Then
                    drawImgX += 1
                    drawImgY += 1
                End If

                g.DrawImage(_img, drawImgX, drawImgY, _img.Width, _img.Height)

                Dim textLeft As Integer = startX + _img.Width + gap
                Dim textW As Integer = Me.Width - textLeft - 4
                If textW < 0 Then textW = 0

                Dim textRect As New Rectangle(textLeft, 0, textW, Me.Height)
                If _pressed Then textRect.Offset(1, 1)

                Dim sideFlags As TextFormatFlags = TextFormatFlags.Left Or _
                                                   TextFormatFlags.VerticalCenter Or _
                                                   TextFormatFlags.NoPrefix Or _
                                                   TextFormatFlags.WordEllipsis

                TextRenderer.DrawText(g, _text, Me.Font, textRect, cText, sideFlags)

            Else
                Dim imgRect As Rectangle = GetAlignedRect(Me.ClientRectangle, _img.Width, _img.Height, _imgAlign)
                Dim drawImgX As Integer = imgRect.X
                Dim drawImgY As Integer = imgRect.Y
                If _pressed Then
                    drawImgX += 1
                    drawImgY += 1
                End If
                g.DrawImage(_img, drawImgX, drawImgY, _img.Width, _img.Height)

                Dim textRect As New Rectangle(0, 0, Me.Width, Me.Height)
                If _pressed Then textRect.Offset(1, 1)

                TextRenderer.DrawText(g, _text, Me.Font, textRect, cText, flags)
            End If

        Else
            Dim textRect As New Rectangle(0, 0, Me.Width, Me.Height)
            If _pressed Then textRect.Offset(1, 1)

            TextRenderer.DrawText(g, _text, Me.Font, textRect, cText, flags)
        End If
    End Sub

    Protected Overrides Sub OnMouseEnter(ByVal e As EventArgs)
        _hover = True
        Invalidate()
        MyBase.OnMouseEnter(e)
    End Sub

    Protected Overrides Sub OnMouseLeave(ByVal e As EventArgs)
        _hover = False
        _pressed = False
        Invalidate()
        MyBase.OnMouseLeave(e)
    End Sub

    Protected Overrides Sub OnMouseDown(ByVal mevent As MouseEventArgs)
        If mevent.Button = MouseButtons.Left Then
            _pressed = True
            Me.Focus()
            Invalidate()
        End If
        MyBase.OnMouseDown(mevent)
    End Sub

    Protected Overrides Sub OnMouseUp(ByVal mevent As MouseEventArgs)
        If _pressed Then
            _pressed = False
            Invalidate()
            If Me.ClientRectangle.Contains(mevent.Location) Then
                Me.OnClick(EventArgs.Empty)
                If _dialogResult <> DialogResult.None Then
                    Dim f As Form = Me.FindForm()
                    If f IsNot Nothing Then
                        f.DialogResult = _dialogResult
                    End If
                End If
            End If
        End If
        MyBase.OnMouseUp(mevent)
    End Sub

    Protected Overrides Sub OnGotFocus(ByVal e As EventArgs)
        Invalidate()
        MyBase.OnGotFocus(e)
    End Sub

    Protected Overrides Sub OnLostFocus(ByVal e As EventArgs)
        _pressed = False
        Invalidate()
        MyBase.OnLostFocus(e)
    End Sub

    Protected Overrides Sub OnKeyDown(ByVal kevent As KeyEventArgs)
        If kevent.KeyCode = Keys.Space OrElse kevent.KeyCode = Keys.Enter Then
            If Not _pressed Then
                _pressed = True
                Invalidate()
            End If
        End If
        MyBase.OnKeyDown(kevent)
    End Sub

    Protected Overrides Sub OnKeyUp(ByVal kevent As KeyEventArgs)
        If _pressed Then
            _pressed = False
            Invalidate()
            If kevent.KeyCode = Keys.Space OrElse kevent.KeyCode = Keys.Enter Then
                Me.OnClick(EventArgs.Empty)
                If _dialogResult <> DialogResult.None Then
                    Dim f As Form = Me.FindForm()
                    If f IsNot Nothing Then
                        f.DialogResult = _dialogResult
                    End If
                End If
            End If
        End If
        MyBase.OnKeyUp(kevent)
    End Sub

    Protected Overrides Sub OnTextChanged(ByVal e As EventArgs)
        Invalidate()
        MyBase.OnTextChanged(e)
    End Sub

    Protected Overrides Sub OnEnabledChanged(ByVal e As EventArgs)
        Invalidate()
        MyBase.OnEnabledChanged(e)
    End Sub
End Class