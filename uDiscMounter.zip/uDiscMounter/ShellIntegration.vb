﻿Imports Microsoft.Win32
Imports System.IO
Imports System.Diagnostics

Module ShellIntegration

    Private ReadOnly Property ExePath() As String
        Get
            Return Application.ExecutablePath
        End Get
    End Property

    Private ReadOnly Property Extensions() As String()
        Get
            Return New String() {".iso", ".bin", ".img", ".cif", ".nrg", _
                                 ".mds", ".ccd", ".bwi", ".isz", ".dmg", _
                                 ".daa", ".uif", ".hfs"}
        End Get
    End Property

    Public Sub RefreshShellMenu()
        Try
            Dim all As List(Of String) = GetAllVirtualDrives()
            If all Is Nothing Then all = New List(Of String)

            Dim used As List(Of String) = GetUsedDrives()

            For Each ext As String In Extensions()
                WriteSubMenuForExtension(ext, all, used)
            Next
        Catch
        End Try
    End Sub

    Private Sub WriteSubMenuForExtension(ByVal ext As String, ByVal allDrives As List(Of String), ByVal usedDrives As List(Of String))
        Dim baseKey As String = "Software\Classes\SystemFileAssociations\" & ext & "\shell\uDiscMounterMountTo"

        Try
            Using k As RegistryKey = Registry.CurrentUser.CreateSubKey(baseKey)
                If k Is Nothing Then Return
                k.SetValue("MUIVerb", "Mount to uDiscMounter", RegistryValueKind.String)
                k.SetValue("Icon", """" & ExePath & """", RegistryValueKind.String)
                k.SetValue("SubCommands", "", RegistryValueKind.String)
            End Using

            Dim shellKey As String = baseKey & "\shell"
            Try
                Registry.CurrentUser.DeleteSubKeyTree(shellKey)
            Catch
            End Try

            If allDrives.Count = 0 Then Return

            Dim idx As Integer = 0
            For Each drv As String In allDrives
                idx += 1
                Dim drvUp As String = drv.ToUpper()
                If Not drvUp.EndsWith(":") Then drvUp &= ":"

                Dim letter As String = drvUp.Replace(":", "")
                Dim num As String = idx.ToString("00")
                Dim itemKey As String = shellKey & "\" & num & letter

                Try
                    Using k As RegistryKey = Registry.CurrentUser.CreateSubKey(itemKey)
                        If k Is Nothing Then Continue For
                        k.SetValue("MUIVerb", "Drive " & drvUp, RegistryValueKind.String)

                        If usedDrives.Contains(drvUp) Then
                            k.SetValue("LegacyDisable", "", RegistryValueKind.String)
                        Else
                            Dim cmd As String = """" & ExePath & """ --mount " & drvUp & " ""%1"""
                            Using ck As RegistryKey = k.CreateSubKey("command")
                                If ck IsNot Nothing Then
                                    ck.SetValue("", cmd, RegistryValueKind.String)
                                End If
                            End Using
                        End If
                    End Using
                Catch
                End Try
            Next
        Catch
        End Try
    End Sub

    Public Sub RemoveShellMenu()
        Try
            For Each ext As String In Extensions()
                Dim baseKey As String = "Software\Classes\SystemFileAssociations\" & ext & "\shell\uDiscMounterMountTo"
                Try
                    Registry.CurrentUser.DeleteSubKeyTree(baseKey)
                Catch
                End Try
            Next
        Catch
        End Try
    End Sub

End Module