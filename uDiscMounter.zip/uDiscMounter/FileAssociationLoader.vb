﻿Module FileAssociationLoader

    Public StartupFile As String = Nothing
    Public StartupMountDrive As String = Nothing
    Public StartupAutoMount As Boolean = False
    Public StartupEjectDrive As String = Nothing

    Public Sub CheckFileAssociationArgs()
        Dim args() As String = Environment.GetCommandLineArgs()

        If args.Length > 1 Then
            Dim a As String = args(1).ToLower()

            If a = "--mount" AndAlso args.Length >= 4 Then
                StartupMountDrive = args(2)
                Dim f As String = args(3)
                If System.IO.File.Exists(f) Then
                    StartupFile = f
                End If

            ElseIf a = "--auto" AndAlso args.Length >= 3 Then
                Dim f As String = args(2)
                If System.IO.File.Exists(f) Then
                    StartupFile = f
                    StartupAutoMount = True
                End If

            ElseIf a = "--eject" AndAlso args.Length >= 3 Then
                StartupEjectDrive = args(2)

            ElseIf a.StartsWith("--") Then

            Else
                Dim f As String = args(1)
                If System.IO.File.Exists(f) Then
                    StartupFile = f
                End If
            End If
        End If
    End Sub

End Module