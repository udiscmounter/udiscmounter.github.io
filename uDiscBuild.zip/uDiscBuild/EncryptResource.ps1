param(
    [Parameter(Mandatory=$true)][string]$InputFile,
    [Parameter(Mandatory=$false)][string]$OutputFile,
    [Parameter(Mandatory=$false)][string]$Password = "uDM_K3y_2024_@#!x9"
)

if ([string]::IsNullOrEmpty($OutputFile)) {
    $OutputFile = $InputFile + ".enc"
}

if (-not (Test-Path $InputFile)) {
    Write-Host "[ERROR] Input file not found: $InputFile" -ForegroundColor Red
    exit 1
}

$sha256 = [System.Security.Cryptography.SHA256]::Create()
$keyBytes = $sha256.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Password))

$md5 = [System.Security.Cryptography.MD5]::Create()
$ivBytes = $md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Password + "_IVSALT_"))

$data = [System.IO.File]::ReadAllBytes($InputFile)

$aes = New-Object System.Security.Cryptography.RijndaelManaged
$aes.KeySize = 256
$aes.BlockSize = 128
$aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
$aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
$aes.Key = $keyBytes
$aes.IV = $ivBytes

$encryptor = $aes.CreateEncryptor()
$encrypted = $encryptor.TransformFinalBlock($data, 0, $data.Length)

[System.IO.File]::WriteAllBytes($OutputFile, $encrypted)

Write-Host "[OK] $InputFile" -ForegroundColor Green
Write-Host "     -> $OutputFile ($($encrypted.Length) bytes)" -ForegroundColor Gray