@echo off
cd /d "%~dp0"
echo ========================================
echo  Encrypting uDiscMounter resources
echo ========================================
echo.

powershell -ExecutionPolicy Bypass -File "%~dp0EncryptResource.ps1" -InputFile "%~dp0IsoCmd.exe"
powershell -ExecutionPolicy Bypass -File "%~dp0EncryptResource.ps1" -InputFile "%~dp0ISODrive.sys"
powershell -ExecutionPolicy Bypass -File "%~dp0EncryptResource.ps1" -InputFile "%~dp0ISODrv64.sys"

echo.
echo Done. Encrypted files:
dir "%~dp0*.enc" /b
echo.
pause