; ========================================================
; uDiscMounter Installer (FIXED VERSION)
; ========================================================

!include "LogicLib.nsh"
!include "WinVer.nsh"
!include "MUI2.nsh"

!define APPNAME "uDiscMounter"
!define VERSION "26.0"

Name "${APPNAME} ${VERSION}"
OutFile "uDiscMounter_x86_x64.exe"
InstallDir "$PROGRAMFILES\${APPNAME}"
RequestExecutionLevel admin

Var ProgramFolder

; ========================================================
; CLASSIC RETRO UI DESIGN
; ========================================================

!define MUI_ICON               "InstallerAssets\setup.ico"
!define MUI_UNICON             "InstallerAssets\uninstall.ico"

!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_BITMAP "InstallerAssets\header.bmp"
!define MUI_HEADERIMAGE_RIGHT

!define MUI_WELCOMEFINISHPAGE_BITMAP "InstallerAssets\sidebar.bmp"
!define MUI_UNWELCOMEFINISHPAGE_BITMAP "InstallerAssets\sidebar.bmp"

!define MUI_ABORTWARNING

Caption "${APPNAME} Installer"
BrandingText "Copyright (c) 2015 - 2026 ARImetic. All Rights Reserved."

InstProgressFlags smooth

; ========================================================
; PAGES
; ========================================================

!insertmacro MUI_PAGE_LICENSE "2.0\eula.txt"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES

!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_TEXT "Run uDiscMounter"
!define MUI_FINISHPAGE_RUN_FUNCTION LaunchApp
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

; ========================================================
; INSTALL SECTION (Satu section utama)
; ========================================================

Section "Install" SecInstall

    SetDetailsPrint none
    
    ; --- Deteksi OS ---
    StrCpy $ProgramFolder ""
    
    ${If} ${AtLeastWin10}
        ; Windows 10, 11, atau lebih baru
        StrCpy $ProgramFolder "4.0"
    ${ElseIf} ${AtLeastWinVista}
        ; Windows Vista, 7, 8, 8.1
        StrCpy $ProgramFolder "2.0"
    ${Else}
        ; Windows XP atau lebih lama - tidak didukung
        MessageBox MB_ICONSTOP "Windows version not supported!$\nMinimum requirement: Windows Vista"
        Quit
    ${EndIf}
    
    ; --- Install executable sesuai OS ---
    SetOutPath "$INSTDIR"
    
    ${If} $ProgramFolder == "2.0"
        ; Windows Vista / 7 / 8 / 8.1
        File "2.0\uDiscMounter.exe"
        DetailPrint "Installing version for Windows Vista/7/8..."
    ${Else}
        ; Windows 10 / 11+
        File "4.0\uDiscMounter.exe"
        DetailPrint "Installing version for Windows 10/11..."
    ${EndIf}
    
    ; --- Install driver files ---
    SetOutPath "$WINDIR"
    File "Driver\IsoCmd.exe"
    File "Driver\ISODrive.sys"
    File "Driver\ISODrv64.sys"
    
    ; --- Silent driver install ---
    ExecWait '"$WINDIR\IsoCmd.exe" -install' $0
    
    ; --- Desktop shortcut ---
    CreateShortcut "$DESKTOP\uDiscMounter.lnk" "$INSTDIR\uDiscMounter.exe"
    
    ; --- Start Menu shortcut (opsional) ---
    CreateDirectory "$SMPROGRAMS\${APPNAME}"
    CreateShortcut "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk" "$INSTDIR\uDiscMounter.exe"
    CreateShortcut "$SMPROGRAMS\${APPNAME}\Uninstall.lnk" "$INSTDIR\Uninstall.exe"
    
    ; --- File associations ---
    WriteRegStr HKCR ".iso" "" "uDiscMounterFile"
    WriteRegStr HKCR ".img" "" "uDiscMounterFile"
    WriteRegStr HKCR ".bin" "" "uDiscMounterFile"
    WriteRegStr HKCR ".cue" "" "uDiscMounterFile"
    WriteRegStr HKCR ".mdf" "" "uDiscMounterFile"
    WriteRegStr HKCR ".mds" "" "uDiscMounterFile"
    WriteRegStr HKCR ".nrg" "" "uDiscMounterFile"
    WriteRegStr HKCR ".uif" "" "uDiscMounterFile"
    WriteRegStr HKCR ".daa" "" "uDiscMounterFile"
    
    WriteRegStr HKCR "uDiscMounterFile" "" "Disc Image File"
    WriteRegStr HKCR "uDiscMounterFile\DefaultIcon" "" "$INSTDIR\uDiscMounter.exe,0"
    WriteRegStr HKCR "uDiscMounterFile\shell" "" "open"
    WriteRegStr HKCR "uDiscMounterFile\shell\open" "" "Mount with uDiscMounter"
    WriteRegStr HKCR "uDiscMounterFile\shell\open\command" "" '"$INSTDIR\uDiscMounter.exe" "%1"'
    
    ; --- Add/Remove Programs entry ---
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" \
                     "DisplayName" "${APPNAME}"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" \
                     "UninstallString" "$\"$INSTDIR\Uninstall.exe$\""
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" \
                     "DisplayIcon" "$INSTDIR\uDiscMounter.exe"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" \
                     "DisplayVersion" "${VERSION}"
    WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" \
                     "Publisher" "ARImetic"
    WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" \
                     "NoModify" 1
    WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}" \
                     "NoRepair" 1
    
    ; --- Write uninstaller ---
    WriteUninstaller "$INSTDIR\Uninstall.exe"
    
    ; --- Refresh shell icons ---
    System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, i 0, i 0)'

SectionEnd

; ========================================================
; UNINSTALL SECTION
; ========================================================

Section "Uninstall"

    SetDetailsPrint none
    
    ; --- Remove driver ---
    ExecWait '"$WINDIR\IsoCmd.exe" -remove' $0
    
    ; --- Delete driver files ---
    Delete "$WINDIR\IsoCmd.exe"
    Delete "$WINDIR\ISODrive.sys"
    Delete "$WINDIR\ISODrv64.sys"
    
    ; --- Delete shortcuts ---
    Delete "$DESKTOP\uDiscMounter.lnk"
    Delete "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk"
    Delete "$SMPROGRAMS\${APPNAME}\Uninstall.lnk"
    RMDir "$SMPROGRAMS\${APPNAME}"
    
    ; --- Remove file associations ---
    DeleteRegKey HKCR "uDiscMounterFile"
    
    ; Restore default associations (opsional - hanya hapus jika masih milik kita)
    ReadRegStr $0 HKCR ".iso" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".iso"
    ${EndIf}
    
    ReadRegStr $0 HKCR ".img" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".img"
    ${EndIf}
    
    ReadRegStr $0 HKCR ".bin" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".bin"
    ${EndIf}
    
    ReadRegStr $0 HKCR ".cue" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".cue"
    ${EndIf}
    
    ReadRegStr $0 HKCR ".mdf" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".mdf"
    ${EndIf}
    
    ReadRegStr $0 HKCR ".mds" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".mds"
    ${EndIf}
    
    ReadRegStr $0 HKCR ".nrg" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".nrg"
    ${EndIf}
    
    ReadRegStr $0 HKCR ".uif" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".uif"
    ${EndIf}
    
    ReadRegStr $0 HKCR ".daa" ""
    ${If} $0 == "uDiscMounterFile"
        DeleteRegKey HKCR ".daa"
    ${EndIf}
    
    ; --- Remove Add/Remove Programs entry ---
    DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}"
    
    ; --- Delete program files ---
    Delete "$INSTDIR\uDiscMounter.exe"
    Delete "$INSTDIR\Uninstall.exe"
    RMDir "$INSTDIR"
    
    ; --- Refresh shell icons ---
    System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, i 0, i 0)'

SectionEnd

; ========================================================
; FUNCTIONS
; ========================================================

Function LaunchApp
    Exec '"$INSTDIR\uDiscMounter.exe"'
FunctionEnd

Function .onInit
    ; Check admin rights
    UserInfo::GetAccountType
    Pop $0
    ${If} $0 != "admin"
        MessageBox MB_ICONSTOP "Administrator rights required!"
        Abort
    ${EndIf}
FunctionEnd

Function un.onInit
    ; Confirm uninstall
    MessageBox MB_YESNO|MB_ICONQUESTION "Are you sure you want to uninstall ${APPNAME}?" IDYES +2
    Abort
FunctionEnd
