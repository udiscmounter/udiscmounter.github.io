﻿Imports System.Diagnostics

Public Class VirtualDrive

    Private Sub VirtualDrive_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        NumericUpDown1.Value = Form1.ComboBox1.Items.Count
        If NumericUpDown1.Value = Form1.ComboBox1.Items.Count Then
            Button1.Enabled = False
        Else
            Button1.Enabled = True
        End If
    End Sub

    Private Sub RunIsoNumber() 
        Try
            Dim angka As Integer = NumericUpDown1.Value
            Dim args As String = "-number " & angka.ToString()
            Dim p As New Process()
            p.StartInfo.FileName = "isocmd.exe"
            p.StartInfo.Arguments = args
            p.StartInfo.UseShellExecute = True ' WAJIB TRUE untuk runas 

            p.StartInfo.Verb = "runas" ' JALANKAN SEBAGAI ADMIN 
            p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
            p.Start() ' Tunggu sampai selesai 
            p.WaitForExit()
            ' ============================ ' PESAN SETELAH SELESAI ' ============================ 
            MessageBox.Show("The operation has completed successfully." & vbCrLf & "Please restart your computer to apply the changes.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("Failed to execute the command as administrator." & vbCrLf & ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        RunIsoNumber()
    End Sub

    Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged
        If NumericUpDown1.Value = Form1.ComboBox1.Items.Count Then
            Button1.Enabled = False
        Else
            Button1.Enabled = True
        End If
    End Sub
End Class
