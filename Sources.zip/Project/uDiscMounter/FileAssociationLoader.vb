﻿Module FileAssociationLoader

    Public StartupFile As String = Nothing

    Public Sub CheckFileAssociationArgs()
        Dim args() As String = Environment.GetCommandLineArgs()

        'Argumen ke-0 = exe
        If args.Length > 1 Then
            Dim f As String = args(1)

            If System.IO.File.Exists(f) Then
                StartupFile = f
            End If
        End If
    End Sub

End Module
