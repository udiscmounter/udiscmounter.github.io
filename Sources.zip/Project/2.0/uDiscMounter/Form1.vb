﻿Imports System.Diagnostics
Imports System.IO
Imports System.Drawing
Imports System.Security.Principal
Public Class Form1
    Private Function FormatSize(ByVal bytes As Long) As String
        Dim size As Double = bytes

        If size < 1024 Then
            Return size.ToString("0") & " B"
        End If

        size /= 1024
        If size < 1024 Then
            Return size.ToString("0.00") & " KB"
        End If

        size /= 1024
        If size < 1024 Then
            Return size.ToString("0.00") & " MB"
        End If

        size /= 1024
        If size < 1024 Then
            Return size.ToString("0.00") & " GB"
        End If

        size /= 1024
        Return size.ToString("0.00") & " TB"
    End Function

    Private Function IsRunningAsAdmin() As Boolean
        Try
            Dim wi As WindowsIdentity = WindowsIdentity.GetCurrent()
            Dim wp As WindowsPrincipal = New WindowsPrincipal(wi)
            Return wp.IsInRole(WindowsBuiltInRole.Administrator)
        Catch
            Return False
        End Try
    End Function
    Private Sub AddFileToGrid(ByVal filePath As String)
        Try
            'ambil file info
            Dim fi As New FileInfo(filePath)

            'ambil icon file
            Dim icon As Icon = icon.ExtractAssociatedIcon(filePath)
            Dim bmp As Bitmap = icon.ToBitmap()

            'hitung size
            Dim sizeText As String = FormatSize(fi.Length)

            'tambah ke datagridview
            DataGridView1.Rows.Add(bmp, fi.Name, sizeText, fi.FullName)
            cekdrv()
            cekitem()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub
    Private Sub LoadIsoCmdDrives()
        ComboBox1.Items.Clear()

        Try
            Dim p As New Process()
            p.StartInfo.FileName = "isocmd.exe"
            p.StartInfo.Arguments = "-print"
            p.StartInfo.UseShellExecute = False
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.CreateNoWindow = True

            p.Start()
            Dim output As String = p.StandardOutput.ReadToEnd()
            p.WaitForExit()

            Dim lines() As String = output.Split(ControlChars.Lf)

            For Each line As String In lines
                line = line.Trim()

                If line.Contains("DriveLetters=[") Then
                    Dim start As Integer = line.IndexOf("["c) + 1
                    Dim finish As Integer = line.IndexOf("]"c)

                    If start > 0 AndAlso finish > start Then
                        Dim inside As String = line.Substring(start, finish - start)
                        inside = inside.Trim()

                        Dim drives() As String

                        If inside.IndexOf(","c) >= 0 Then
                            ' Format: E,F,G
                            drives = inside.Split(","c)
                        Else
                            ' Format: EF  -> split per karakter tanpa LINQ
                            If inside.Length > 0 Then
                                ReDim drives(inside.Length - 1)
                                Dim i As Integer
                                For i = 0 To inside.Length - 1
                                    drives(i) = inside.Substring(i, 1)
                                Next
                            Else
                                ReDim drives(-1) ' kosong
                            End If
                        End If

                        Dim d As String
                        For Each d In drives
                            If d IsNot Nothing Then
                                d = d.Trim()
                                If d <> "" Then
                                    ComboBox1.Items.Add(d & ":")
                                End If
                            End If
                        Next
                    End If
                End If
            Next

            If ComboBox1.Items.Count > 0 Then
                ComboBox1.SelectedIndex = 0
            End If

        Catch ex As Exception
            ' MessageBox.Show("Gagal menjalankan isocmd.exe -print" & vbCrLf & ex.Message)
        End Try
    End Sub

    Private Sub Form1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragDrop
        Try
            Dim files() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())

            ' Daftar ekstensi valid
            Dim allowedExt() As String = {".iso", ".bin", ".img", ".cif", ".nrg",
                                          ".mds", ".ccd", ".bwi", ".isz", ".dmg",
                                          ".daa", ".uif", ".hfs"}

            For Each f As String In files

                Dim ext As String = LCase(System.IO.Path.GetExtension(f))

                ' CEK EKSTENSI
                If Array.IndexOf(allowedExt, ext) = -1 Then
                    MessageBox.Show("Format not supported: " & f)
                    Continue For
                End If

                ' CEK DUPLIKAT
                Dim isDuplicate As Boolean = False
                For Each row As DataGridViewRow In DataGridView1.Rows
                    If row.Cells(3).Value IsNot Nothing Then
                        If row.Cells(3).Value.ToString().ToLower() = f.ToLower() Then
                            isDuplicate = True
                            Exit For
                        End If
                    End If
                Next

                If isDuplicate Then
                    MessageBox.Show("The file already exists in the list: " & f)
                    Continue For
                End If

                ' Jika lolos → masukkan
                AddFileToGrid(f)
            Next

            cekitem()

        Catch ex As Exception
            MessageBox.Show("Drag & Drop Error: " & ex.Message)
        End Try
    End Sub

    Private Sub Form1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Sub cekdrv()
        If ComboBox1.Items.Count > 0 Then
            ComboBox1.Enabled = True
            LinkLabel1.Enabled = True
            If AdaItem() Then
                Button2.Enabled = True
                Button3.Enabled = True
            Else
                Button2.Enabled = False
                Button3.Enabled = False
            End If
        Else
            ComboBox1.Enabled = False
            LinkLabel1.Enabled = False
            Button2.Enabled = False
            Button3.Enabled = False
        End If
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CheckFileAssociationArgs()
        LoadIsoCmdDrives()
        cekdrv()
        If StartupFile IsNot Nothing Then
            cekdrv()
            AddFileToGrid(StartupFile)
            Button5.Enabled = True
            Panel1.Visible = False
            TextBox1.Text = StartupFile
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.ActiveControl = Nothing
        Dim dlg As New OpenFileDialog()
        dlg.Multiselect = True

        ' Filter optional (boleh dipakai atau tidak)
        dlg.Filter = "Disc Image Files|*.iso;*.bin;*.img;*.cif;*.nrg;*.mds;*.ccd;*.bwi;*.isz;*.dmg;*.daa;*.uif;*.hfs"

        If dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then

            ' Daftar ekstensi yang diperbolehkan (lowercase semua)
            Dim allowedExt() As String = {".iso", ".bin", ".img", ".cif", ".nrg", _
                                          ".mds", ".ccd", ".bwi", ".isz", ".dmg", _
                                          ".daa", ".uif", ".hfs"}

            For Each f As String In dlg.FileNames

                Dim ext As String = LCase(System.IO.Path.GetExtension(f))

                ' CEK FORMAT TIDAK DIDUKUNG
                If Array.IndexOf(allowedExt, ext) = -1 Then
                    MessageBox.Show("Format tidak didukung: " & f)
                    Continue For
                End If

                ' CEK DUPLIKAT (CEK File Path dalam DataGridView)
                Dim isDuplicate As Boolean = False

                For Each row As DataGridViewRow In DataGridView1.Rows
                    If row.Cells(3).Value IsNot Nothing Then
                        If row.Cells(3).Value.ToString().ToLower() = f.ToLower() Then
                            isDuplicate = True
                            Exit For
                        End If
                    End If
                Next

                If isDuplicate Then
                    MessageBox.Show("The file already exists in the list: " & f)
                    Continue For
                End If

                ' Jika lolos semua → tambahkan ke grid
                AddFileToGrid(f)
                cekitem()
                cekdrv()
            Next
        End If
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim row As DataGridViewRow = DataGridView1.SelectedRows(0)
            TextBox1.Text = row.Cells(3).Value.ToString()
            cekdrv()
            Button4.Enabled = True
        Else
            Button2.Enabled = False
            Button3.Enabled = False
            Button4.Enabled = False
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim row As DataGridViewRow = DataGridView1.SelectedRows(0)
            TextBox1.Text = row.Cells(3).Value.ToString()
            cekdrv()
            Button4.Enabled = True
        Else
            Button2.Enabled = False
            Button3.Enabled = False
            Button4.Enabled = False
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.ActiveControl = Nothing
        Dim drive As String = ComboBox1.Text
        Dim iso As String = TextBox1.Text

        Dim result As String = MountISO(drive, iso)
        Process.Start(drive)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.ActiveControl = Nothing
        Dim drive As String = ComboBox1.Text
        Dim result As String = EjectISO(drive)
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        VirtualDrive.ShowDialog()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For Each row As DataGridViewRow In DataGridView1.SelectedRows
                DataGridView1.Rows.Remove(row)
            Next
            cekitem()
        Else
            '
        End If
    End Sub
    Private Function AdaItem() As Boolean
        Return DataGridView1.Rows.Count > 0
    End Function
    Private Sub cekitem()
        If AdaItem() Then
            Panel1.Visible = False
            Button5.Enabled = True
        Else
            Button5.Enabled = False
            Panel1.Visible = True
        End If
    End Sub
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        DataGridView1.Rows.Clear()
        cekitem()
    End Sub

    Private Sub OpenFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFileToolStripMenuItem.Click
        Button1.PerformClick()
    End Sub

    Private Sub MountToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MountToolStripMenuItem.Click
        Button2.PerformClick()
    End Sub

    Private Sub EjectToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EjectToolStripMenuItem.Click
        Button3.PerformClick()
    End Sub

    Private Sub DelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DelToolStripMenuItem.Click
        Button4.PerformClick()
    End Sub

    Private Sub ClearToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripMenuItem.Click
        Button5.PerformClick()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Me.ActiveControl = Nothing
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Me.ActiveControl = Nothing
        frmHelp.ShowDialog()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Me.ActiveControl = Nothing
        frmAbout.ShowDialog()
    End Sub

    Private Sub DelToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DelToolStripMenuItem1.Click
        Button4.PerformClick()
    End Sub

    Private Sub ClearToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripMenuItem1.Click
        Button5.PerformClick()
    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click

    End Sub

    Private Sub Label6_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label6.MouseEnter
        Label6.ForeColor = SystemColors.ActiveCaption
    End Sub

    Private Sub Label6_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label6.MouseLeave
        Label6.ForeColor = SystemColors.ControlDark
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            Me.TopMost = True
        Else
            Me.TopMost = False
        End If
    End Sub

    Private Sub CheckBox1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox1.MouseEnter
        CheckBox1.ForeColor = Color.Firebrick
    End Sub

    Private Sub CheckBox1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox1.MouseLeave
        CheckBox1.ForeColor = Color.Black
    End Sub

    Private Sub HelpToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpToolStripMenuItem.Click
        Button6.PerformClick()
    End Sub
End Class
