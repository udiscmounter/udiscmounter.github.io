﻿Imports System.Diagnostics
Module Operations
    Public Function MountISO(ByVal driveLetter As String, ByVal isoPath As String) As String
        Try
            'Pastikan ada ":" di drive
            If driveLetter.EndsWith(":") = False Then
                driveLetter &= ":"
            End If

            'Bentuk perintah
            Dim args As String = "-mount " & driveLetter & " """ & isoPath & """"

            Dim p As New Process()
            p.StartInfo.FileName = "isocmd.exe"
            p.StartInfo.Arguments = args
            p.StartInfo.UseShellExecute = False
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.RedirectStandardError = True
            p.StartInfo.CreateNoWindow = True

            p.Start()

            Dim output As String = p.StandardOutput.ReadToEnd()
            Dim err As String = p.StandardError.ReadToEnd()

            p.WaitForExit()

            If err.Trim() <> "" Then
                Return "ERROR: " & err
            Else
                Return output
            End If

        Catch ex As Exception
            Return "Exception: " & ex.Message
        End Try
    End Function
    Public Function EjectISO(ByVal driveLetter As String) As String
        Try
            'Pastikan ada ":" di drive
            If driveLetter.EndsWith(":") = False Then
                driveLetter &= ":"
            End If

            'Perintah isocmd
            Dim args As String = "-eject " & driveLetter

            Dim p As New Process()
            p.StartInfo.FileName = "isocmd.exe"
            p.StartInfo.Arguments = args
            p.StartInfo.UseShellExecute = False
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.RedirectStandardError = True
            p.StartInfo.CreateNoWindow = True

            p.Start()

            Dim output As String = p.StandardOutput.ReadToEnd()
            Dim err As String = p.StandardError.ReadToEnd()

            p.WaitForExit()

            If err.Trim() <> "" Then
                Return "ERROR: " & err
            Else
                Return output
            End If

        Catch ex As Exception
            Return "Exception: " & ex.Message
        End Try
    End Function

End Module
